import {token,hash,equal,passwordHash,passwordMatches,signTicket,verifyTicket,profileKey} from './account-crypto.mjs';
const COOKIE='__Host-orbit-session';
const REMEMBER_AGE=365*86400;
const noStore={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json=(body,status=200,headers={})=>Response.json(body,{status,headers:{...noStore,...headers}});
export function cookie(request,name){return request.headers.get('Cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';}
export function engineTicket(request){return request.headers.get('X-Orbit-Ticket')||request.headers.get('Authorization')?.replace(/^Bearer /i,'')||'';}
function db(env){if(!env.DB||!env.ORBIT_TICKET_SECRET||!env.ORBIT_PROFILE_SECRET||!env.ORBIT_ENGINE_ORIGIN)throw new Error('Accounts are not configured');return env.DB;}
function sessionCookie(value,age){return `${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;}
export async function authenticate(request,env){
  const value=cookie(request,COOKIE);if(!/^[-\w]{43}$/.test(value))return null;
  return db(env).prepare('SELECT u.id,u.username,u.role,s.hash AS sid,s.expires,s.remembered FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.hash=? AND s.expires>? AND u.disabled=0').bind(hash(value),Date.now()).first();
}
async function renewSession(request,env,user){
  const now=Date.now();
  if(!user.remembered||user.expires>now+(REMEMBER_AGE-86400)*1000)return {};
  await db(env).prepare('UPDATE sessions SET expires=? WHERE hash=? AND expires>?').bind(now+REMEMBER_AGE*1000,user.sid,now).run();
  return {'Set-Cookie':sessionCookie(cookie(request,COOKIE),REMEMBER_AGE)};
}
async function limit(env,key,max,period){
  const now=Date.now();const result=await db(env).prepare('INSERT INTO auth_limits (key,count,expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<=? THEN 1 ELSE count+1 END,expires=CASE WHEN expires<=? THEN ? ELSE expires END RETURNING count').bind(hash(key),now+period,now,now,now+period).first();
  // Bounded cleanup: keys contain no raw IPs or usernames.
  if(Math.random()<.02)await db(env).prepare('DELETE FROM auth_limits WHERE expires<?').bind(now).run();
  return result.count<=max;
}
async function body(request,max=16384){
  if(request.headers.get('Content-Type')?.split(';')[0]!=='application/json')throw Object.assign(new Error('JSON required'),{status:415});
  if(Number(request.headers.get('Content-Length'))>max)throw Object.assign(new Error('Request too large'),{status:413});
  const reader=request.body?.getReader();if(!reader)throw Object.assign(new Error('Invalid request'),{status:400});
  let length=0,chunks=[];for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>max){await reader.cancel();throw Object.assign(new Error('Request too large'),{status:413});}chunks.push(value);}
  try{const all=new Uint8Array(length);let at=0;for(const c of chunks){all.set(c,at);at+=c.length;}const value=JSON.parse(new TextDecoder().decode(all));if(!value||Array.isArray(value)||typeof value!=='object')throw 0;return value;}catch{throw Object.assign(new Error('Invalid request'),{status:400});}
}
function credentials(input){
  const username=typeof input.username==='string'?input.username.trim().toLowerCase():'';
  if(!/^[a-z0-9][a-z0-9_.-]{2,23}$/.test(username))throw Object.assign(new Error('Use a username of 3–24 letters, numbers, dots, underscores or hyphens.'),{status:400});
  if(typeof input.password!=='string'||[...input.password].length<15||[...input.password].length>128||new TextEncoder().encode(input.password).length>256)throw Object.assign(new Error('Use a password or passphrase with 15–128 characters.'),{status:400});
  return {username,password:input.password};
}
async function startSession(user,env,remember,old){
  const value=token(),age=remember?REMEMBER_AGE:12*3600;
  const statements=[db(env).prepare('INSERT INTO sessions (hash,user_id,expires,remembered) VALUES (?,?,?,?)').bind(hash(value),user.id,Date.now()+age*1000,remember?1:0)];
  if(old)statements.push(db(env).prepare('DELETE FROM sessions WHERE hash=?').bind(hash(old)));
  await db(env).batch(statements);
  return json({user:{id:user.id,username:user.username,role:user.role}},200,{'Set-Cookie':sessionCookie(value,age)});
}
export async function accountRoutes(request,env){
  const url=new URL(request.url),path=url.pathname;
  if(!path.startsWith('/api/'))return null;
  try{
    db(env);
    if(path==='/api/engine-authorize'){
      if(request.method!=='POST')return json({error:'Request not allowed'},405);
      const p=verifyTicket(engineTicket(request),env.ORBIT_TICKET_SECRET,{issuer:url.origin,audience:env.ORBIT_ENGINE_ORIGIN});
      if(!p)return json({error:'Sign in required'},401);
      const active=await db(env).prepare('SELECT u.id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.hash=? AND s.user_id=? AND s.expires>? AND u.disabled=0').bind(p.sid,p.sub,Date.now()).first();
      return active?json({id:active.id,key:profileKey(active.id,env.ORBIT_PROFILE_SECRET)}):json({error:'Session expired'},401);
    }
    if(request.method!=='GET'&&request.headers.get('Origin')!==url.origin)return json({error:'Request not allowed'},403);
    if(path==='/api/account'&&request.method==='GET'){
      const user=await authenticate(request,env);return user?json({user:{id:user.id,username:user.username,role:user.role},key:profileKey(user.id,env.ORBIT_PROFILE_SECRET),engine:env.ORBIT_ENGINE_ORIGIN},200,await renewSession(request,env,user)):json({user:null},401);
    }
    if(['/api/login','/api/register','/api/setup'].includes(path)&&request.method==='POST'){
      const ip=request.headers.get('CF-Connecting-IP')||'unknown';
      if(!await limit(env,'ip:'+ip,15,15*60000))return json({error:'Too many attempts. Try again in 15 minutes.'},429,{'Retry-After':'900'});
      const input=await body(request),c=credentials(input);
      if(!await limit(env,'user:'+c.username,10,15*60000))return json({error:'Too many attempts. Try again in 15 minutes.'},429);
      if(path==='/api/login'){
        const user=await db(env).prepare('SELECT id,username,password,role,disabled FROM users WHERE username=?').bind(c.username).first();
        // Spend the same scrypt work for unknown accounts.
        const matches=user?await passwordMatches(c.password,user.password):(await passwordHash(c.password),false);
        if(!matches||user.disabled)return json({error:'Username or password is incorrect.'},401);
        return startSession(user,env,input.remember!==false,cookie(request,COOKIE));
      }
      const isOwner=path==='/api/setup';
      if(typeof input.code!=='string'||!/^[-\w]{43}$/.test(input.code))return json({error:'A valid invitation is required.'},403);
      const codeHash=hash(input.code),now=Date.now();
      if(isOwner){
        if(!env.ORBIT_SETUP_HASH||!equal(codeHash,env.ORBIT_SETUP_HASH)||await db(env).prepare("SELECT id FROM users WHERE role='owner'").first())return json({error:'This setup link is invalid or has already been used.'},403);
      }else if(!await db(env).prepare('SELECT hash FROM invites WHERE hash=? AND claimed_by IS NULL AND expires>?').bind(codeHash,now).first())return json({error:'This invitation is invalid, expired, or already used.'},403);
      const user={id:token(),username:c.username,role:isOwner?'owner':'member'},password=await passwordHash(c.password);
      try{
        if(isOwner)await db(env).prepare('INSERT INTO users (id,username,password,role,created) VALUES (?,?,?,?,?)').bind(user.id,user.username,password,user.role,now).run();
        else{
          // Claim only if still unused; transaction makes races safe.
          await db(env).batch([
            db(env).prepare('INSERT INTO users (id,username,password,role,created) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM invites WHERE hash=? AND claimed_by IS NULL AND expires>?)').bind(user.id,user.username,password,user.role,now,codeHash,now),
            db(env).prepare('UPDATE invites SET claimed_by=? WHERE hash=? AND claimed_by IS NULL AND EXISTS (SELECT 1 FROM users WHERE id=?)').bind(user.id,codeHash,user.id),
          ]);
          if(!await db(env).prepare('SELECT id FROM users WHERE id=?').bind(user.id).first())return json({error:'This invitation has already been used.'},403);
        }
      }catch(error){if(/UNIQUE|constraint/i.test(String(error)))return json({error:'This username or invitation is no longer available.'},409);throw error;}
      return startSession(user,env,input.remember!==false,cookie(request,COOKIE));
    }
    const user=await authenticate(request,env);if(!user)return json({error:'Sign in required'},401);
    if(path==='/api/logout'&&request.method==='POST'){
      await db(env).prepare('DELETE FROM sessions WHERE hash=?').bind(user.sid).run();return json({ok:true},200,{'Set-Cookie':sessionCookie('',0)});
    }
    if(path==='/api/profile'&&request.method==='GET'){
      const profile=await db(env).prepare('SELECT cipher,updated FROM profiles WHERE user_id=?').bind(user.id).first();return json({cipher:profile?.cipher||null,updated:profile?.updated||0});
    }
    if(path==='/api/profile'&&request.method==='PUT'){
      const input=await body(request,750000);if(input.userId!==user.id)return json({error:'Your account changed. Reload Orbit before saving.'},409);
      if(typeof input.cipher!=='string'||input.cipher.length>700000||!/^v1\.[A-Za-z0-9_-]+$/.test(input.cipher))return json({error:'Invalid profile'},400);
      await db(env).prepare('INSERT INTO profiles (user_id,cipher,updated) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET cipher=excluded.cipher,updated=excluded.updated').bind(user.id,input.cipher,Date.now()).run();return json({ok:true});
    }
    if(path==='/api/engine-ticket'&&request.method==='POST')return json({ticket:signTicket({iss:url.origin,aud:env.ORBIT_ENGINE_ORIGIN,sub:user.id,sid:user.sid,exp:Date.now()+10*60000},env.ORBIT_TICKET_SECRET)},200,await renewSession(request,env,user));
    if(path==='/api/invites'&&request.method==='POST'){
      if(user.role!=='owner')return json({error:'Only the owner can invite people.'},403);
      if(!await limit(env,'invite:'+user.id,30,3600000))return json({error:'Invitation limit reached. Try again later.'},429);
      const code=token(),expires=Date.now()+7*86400000;await db(env).prepare('INSERT INTO invites (hash,owner_id,expires) VALUES (?,?,?)').bind(hash(code),user.id,expires).run();return json({url:url.origin+'/#invite='+code,expires});
    }
    if(path==='/api/password'&&request.method==='POST'){
      const input=await body(request),c=credentials({username:user.username,password:input.password});
      if(typeof input.currentPassword!=='string'||input.currentPassword.length>256)return json({error:'Current password required'},400);
      if(!await limit(env,'password:'+user.id,5,15*60000))return json({error:'Too many attempts'},429);
      const row=await db(env).prepare('SELECT password FROM users WHERE id=?').bind(user.id).first();if(!await passwordMatches(input.currentPassword,row.password))return json({error:'Current password is incorrect.'},401);
      await db(env).batch([db(env).prepare('UPDATE users SET password=? WHERE id=?').bind(await passwordHash(c.password),user.id),db(env).prepare('DELETE FROM sessions WHERE user_id=? AND hash<>?').bind(user.id,user.sid)]);return json({ok:true});
    }
    return null;
  }catch(error){
    if(error.status)return json({error:error.message},error.status);
    console.error('ORBIT_ACCOUNTS_UNAVAILABLE');return json({error:'Accounts are temporarily unavailable. Please try again.'},503);
  }
}
