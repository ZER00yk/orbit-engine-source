import {createServer} from 'node:http';
import {timingSafeEqual} from 'node:crypto';
import {server as wisp,logging} from '@mercuryworkshop/wisp-js/server';

export function createRelay({token,allowedOrigin}) {
  if(typeof token!=='string' || token.length<32)throw new Error('Set RELAY_TOKEN to a random secret of at least 32 characters.');
  if(!allowedOrigin || new URL(allowedOrigin).protocol!=='https:')throw new Error('Set RELAY_ALLOWED_ORIGIN to the HTTPS origin of your Orbit site.');
  const secret=Buffer.from(`Bearer ${token}`);
  logging.set_level(logging.NONE);
  Object.assign(wisp.options,{
    allow_udp_streams:false,
    allow_direct_ip:false,
    allow_private_ips:false,
    allow_loopback_ips:false,
    port_whitelist:[80,443],
    stream_limit_per_host:24,
    stream_limit_total:128,
    hostname_blacklist:[/^localhost$/i,/\.localhost$/i,/\.local$/i],
    parse_real_ip:false,
  });
  const server=createServer((req,res)=>{
    if(req.url==='/health'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end('{"ok":true}');return;}
    res.writeHead(404);res.end('Not found');
  });
  server.on('upgrade',(req,socket,head)=>{
    const received=Buffer.from(req.headers.authorization||'');
    const authorized=received.length===secret.length && timingSafeEqual(received,secret);
    if(req.url!=='/wisp/' || !authorized || req.headers.origin!==allowedOrigin){socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');socket.destroy();return;}
    wisp.routeRequest(req,socket,head);
  });
  return server;
}
if(process.argv[1] && import.meta.url===new URL(`file://${process.argv[1]}`).href){
  const server=createRelay({token:process.env.RELAY_TOKEN,allowedOrigin:process.env.RELAY_ALLOWED_ORIGIN});
  server.listen(Number(process.env.PORT)||8080,'0.0.0.0',()=>console.log('Private Wisp relay is listening.'));
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>process.exit(0)));
}
