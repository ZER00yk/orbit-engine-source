import {gcm} from '@noble/ciphers/aes.js';

// OPFS is shared by every tab at the engine origin. Expose only a user's
// virtual website directory, and store independently authenticated 64 KiB
// blocks so game workers can read large packs without decrypting whole files.
const BLOCK=65536,HEADER=128,SLOT=BLOCK+28;
const MAGIC=new TextEncoder().encode('ORBITFS1'),utf8=new TextEncoder();
const MAX_SIZE=Math.floor((Number.MAX_SAFE_INTEGER-HEADER)/SLOT)*BLOCK;
const failure=(message,name='SecurityError')=>new DOMException(message,name);
function size(value){value=Number(value);if(!Number.isSafeInteger(value)||value<0||value>MAX_SIZE)throw new TypeError('Invalid private file offset');return value;}
function bytes(value){if(ArrayBuffer.isView(value))return new Uint8Array(value.buffer,value.byteOffset,value.byteLength);if(value instanceof ArrayBuffer||typeof SharedArrayBuffer!=='undefined'&&value instanceof SharedArrayBuffer)return new Uint8Array(value);throw new TypeError('File data must be an ArrayBuffer or view');}
function concat(...parts){const value=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let at=0;for(const p of parts){value.set(p,at);at+=p.length;}return value;}
const random=n=>crypto.getRandomValues(new Uint8Array(n));
const physicalSize=n=>HEADER+Math.ceil(n/BLOCK)*SLOT;
function contextFor(context,origin){return {id:context.id,key:context.bytes,origin,prefix:utf8.encode('orbit-opfs-v1:'+context.id+':'+origin+':')};}
function aad(context,salt,index){const suffix=new Uint8Array(8);new DataView(suffix.buffer).setBigInt64(0,BigInt(index),true);return concat(context.prefix,salt,suffix);}
function headerFor(context,state){const plain=new Uint8Array(16),view=new DataView(plain.buffer);view.setBigUint64(0,BigInt(state.size),true);view.setUint32(8,BLOCK,true);view.setUint32(12,1,true);const nonce=random(12),out=new Uint8Array(HEADER);out.set(MAGIC);out.set(state.salt,8);out.set(nonce,24);out.set(gcm(context.key,nonce,aad(context,state.salt,-1)).encrypt(plain),36);return out;}
function readHeader(context,value){
  if(value.length!==HEADER||!MAGIC.every((b,i)=>b===value[i]))throw failure('Invalid encrypted file','NotReadableError');
  try{const salt=value.slice(8,24),plain=gcm(context.key,value.slice(24,36),aad(context,salt,-1)).decrypt(value.slice(36,68)),view=new DataView(plain.buffer,plain.byteOffset,plain.byteLength);
    if(view.getUint32(8,true)!==BLOCK||view.getUint32(12,true)!==1)throw new Error();return {salt,size:size(Number(view.getBigUint64(0,true)))};
  }catch{throw failure('This file does not belong to the current private profile','NotReadableError');}
}
function encodeBlock(context,state,index,plain){const nonce=random(12);return concat(nonce,gcm(context.key,nonce,aad(context,state.salt,index)).encrypt(plain));}
function decodeBlock(context,state,index,value){if(value.length!==SLOT)throw failure('Incomplete encrypted file block','NotReadableError');try{return gcm(context.key,value.subarray(0,12),aad(context,state.salt,index)).decrypt(value.subarray(12));}catch{throw failure('Invalid encrypted file block','NotReadableError');}}

export function createProfileFiles(getContext){
  const DP=globalThis.FileSystemDirectoryHandle?.prototype,FP=globalThis.FileSystemFileHandle?.prototype,HP=globalThis.FileSystemHandle?.prototype,AP=globalThis.FileSystemSyncAccessHandle?.prototype;
  const getDirectory=globalThis.StorageManager?.prototype.getDirectory;
  if(!DP||!FP||!HP||!getDirectory)return {bind(){},directory(){return Promise.reject(failure('Private file storage is unavailable','NotSupportedError'));}};
  const native={getDirectory,dir:DP.getDirectoryHandle,file:DP.getFileHandle,entries:DP.entries,resolve:DP.resolve,remove:DP.removeEntry,getFile:FP.getFile,writable:FP.createWritable,sync:FP.createSyncAccessHandle,same:HP.isSameEntry,name:Object.getOwnPropertyDescriptor(HP,'name')?.get};
  if(AP)for(const name of ['read','write','getSize','truncate','flush','close'])native[name]=AP[name];
  const handles=new WeakMap(),accesses=new WeakMap(),cache=new Map(),active=new Set();
  let origin=null;
  function current(){const p=getContext();if(!origin)throw failure('A website profile is required');return contextFor(p,origin);}
  function assert(context){const p=getContext();if(p.id!==context.id||p.bytes!==context.key||origin!==context.origin)throw failure('The browsing profile is no longer active');}
  function info(handle){const value=handles.get(handle);if(!value)throw failure('This file handle is outside the private website');assert(value.context);return value;}
  function register(handle,context,path,writerRoot){handles.set(handle,{context,path,writerRoot});return handle;}
  function bind(value){const url=new URL(value);if(!['https:','http:'].includes(url.protocol)||url.origin!==value)throw failure('Invalid website file scope');getContext();if(origin&&origin!==value)throw failure('The website file scope changed');origin=value;}
  async function directory(value){bind(value);const context=current(),root=await native.getDirectory.call(navigator.storage);assert(context);
    const user=await native.dir.call(root,'orbit-files-'+context.id,{create:true});
    const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',utf8.encode(value))),name=Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('');
    const site=await native.dir.call(user,name,{create:true});assert(context);return register(site,context,[],{user,name});
  }
  if(native.name)Object.defineProperty(HP,'name',{configurable:true,enumerable:true,get(){const meta=handles.get(this);return meta?meta.path.at(-1)||'':native.name.call(this);}});
  DP.getDirectoryHandle=async function(name,options){const meta=info(this),handle=await native.dir.call(this,name,options);assert(meta.context);return register(handle,meta.context,[...meta.path,String(name)],meta.writerRoot);};
  DP.getFileHandle=async function(name,options){const meta=info(this),handle=await native.file.call(this,name,options);assert(meta.context);return register(handle,meta.context,[...meta.path,String(name)],meta.writerRoot);};
  DP.entries=async function*(){const meta=info(this);for await(const [name,handle] of native.entries.call(this)){assert(meta.context);yield [name,register(handle,meta.context,[...meta.path,name],meta.writerRoot)];}};
  DP.keys=async function*(){for await(const [name] of this.entries())yield name;};
  DP.values=async function*(){for await(const [,handle] of this.entries())yield handle;};
  DP[Symbol.asyncIterator]=DP.entries;
  DP.removeEntry=function(name,options){info(this);return native.remove.call(this,name,options);};
  DP.resolve=function(handle){const a=info(this),b=info(handle);if(a.context.id!==b.context.id||a.context.origin!==b.context.origin)return Promise.resolve(null);return native.resolve.call(this,handle);};
  HP.isSameEntry=function(handle){const a=info(this),b=info(handle);if(a.context.id!==b.context.id||a.context.origin!==b.context.origin)return Promise.resolve(false);return native.same.call(this,handle);};
  // A cloned native handle has no verified directory scope in the receiving
  // realm. Fail closed rather than accidentally exposing another user's tree.
  for(const proto of new Set([HP,DP,FP]))for(const name of ['move','remove'])if(typeof proto[name]==='function')Object.defineProperty(proto,name,{configurable:true,writable:true,value(){throw failure('Moving private file handles is unavailable','NotSupportedError');}});
  for(const name of ['queryPermission','requestPermission'])if(HP[name]){const original=HP[name];HP[name]=function(...args){info(this);return original.apply(this,args);};}
  const LP=globalThis.LockManager?.prototype;
  if(LP){const request=LP.request,query=LP.query,prefix=()=>{const context=current();return 'orbit-files:'+context.id+':'+context.origin+':';};
    LP.request=function(name,options,callback){const scoped=prefix(),value=String(name),fn=typeof options==='function'?options:callback;if(typeof fn!=='function')throw new TypeError('A lock callback is required');const wrap=lock=>fn(lock===null?null:new Proxy(lock,{get(target,key){return key==='name'?value:Reflect.get(target,key,target);}}));return typeof options==='function'?request.call(this,scoped+value,wrap):request.call(this,scoped+value,options,wrap);};
    if(query)LP.query=async function(){const scoped=prefix(),result=await query.call(this),filter=list=>list.filter(lock=>lock.name.startsWith(scoped)).map(lock=>({...lock,name:lock.name.slice(scoped.length)}));return {held:filter(result.held),pending:filter(result.pending)};};
  }

  function cacheGet(state,index){const hit=cache.get(state)?.get(index);return hit;}
  function cachePut(state,index,value){let entry=cache.get(state);if(!entry){if(cache.size>=32)cache.delete(cache.keys().next().value);cache.set(state,entry=new Map());}entry.clear();entry.set(index,value);}
  function rawRead(access,at,length){const out=new Uint8Array(length);let count=0;while(count<length){const n=native.read.call(access,out.subarray(count),{at:at+count});if(!n)break;count+=n;}return out.subarray(0,count);}
  function rawWrite(access,value,at){let count=0;while(count<value.length){const n=native.write.call(access,value.subarray(count),{at:at+count});if(!n)throw failure('Private file write made no progress','OperationError');count+=n;}}
  function accessState(handle){const state=accesses.get(handle);if(!state||state.closed)throw failure('The file access handle is closed','InvalidStateError');assert(state.context);return state;}
  function syncBlock(access,state,index){const hit=cacheGet(state,index);if(hit)return hit;const value=index>=Math.ceil(state.size/BLOCK)?new Uint8Array(BLOCK):decodeBlock(state.context,state,index,rawRead(access,HEADER+index*SLOT,SLOT));cachePut(state,index,value);return value;}
  function syncSave(access,state,index,value){rawWrite(access,encodeBlock(state.context,state,index,value),HEADER+index*SLOT);cachePut(state,index,value);}
  function syncHeader(access,state){rawWrite(access,headerFor(state.context,state),0);state.initialised=true;}
  if(native.sync&&AP){
    FP.createSyncAccessHandle=async function(options={}){const meta=info(this);if(options.mode==='readwrite-unsafe')throw failure('Private files require an exclusive writer','NotSupportedError');const access=await native.sync.call(this,options);try{assert(meta.context);const length=native.getSize.call(access),header=length?readHeader(meta.context,rawRead(access,0,HEADER)):{size:0,salt:random(16)};if(length&&length<physicalSize(header.size))throw failure('Incomplete encrypted file','NotReadableError');accesses.set(access,{...header,context:meta.context,cursor:0,initialised:!!length,closed:false,readonly:options.mode==='read-only'});active.add(access);return access;}catch(error){native.close.call(access);throw error;}};
    Object.defineProperty(FP.createSyncAccessHandle,'length',{value:native.sync.length});
    AP.getSize=function(){return accessState(this).size;};
    AP.read=function(buffer,options={}){const state=accessState(this),out=bytes(buffer),at=size(options.at??state.cursor),count=Math.min(out.length,Math.max(0,state.size-at));let done=0;while(done<count){const index=Math.floor((at+done)/BLOCK),offset=(at+done)%BLOCK,n=Math.min(count-done,BLOCK-offset);out.set(syncBlock(this,state,index).subarray(offset,offset+n),done);done+=n;}state.cursor=at+count;return count;};
    AP.write=function(buffer,options={}){const state=accessState(this);if(state.readonly)throw failure('The file is read-only','NoModificationAllowedError');const input=bytes(buffer),at=size(options.at??state.cursor);size(at+input.length);if(input.length)for(let index=Math.ceil(state.size/BLOCK);index<Math.floor(at/BLOCK);index++)syncSave(this,state,index,new Uint8Array(BLOCK));let done=0;while(done<input.length){const index=Math.floor((at+done)/BLOCK),offset=(at+done)%BLOCK,n=Math.min(input.length-done,BLOCK-offset),value=syncBlock(this,state,index).slice();value.set(input.subarray(done,done+n),offset);syncSave(this,state,index,value);done+=n;}if(done){state.size=Math.max(state.size,at+done);syncHeader(this,state);}state.cursor=at+done;return done;};
    AP.truncate=function(value){const state=accessState(this);if(state.readonly)throw failure('The file is read-only','NoModificationAllowedError');const next=size(value);if(next<state.size&&next%BLOCK){const index=Math.floor(next/BLOCK),block=syncBlock(this,state,index).slice();block.fill(0,next%BLOCK);syncSave(this,state,index,block);}if(next>state.size)for(let index=Math.ceil(state.size/BLOCK);index<Math.ceil(next/BLOCK);index++)syncSave(this,state,index,new Uint8Array(BLOCK));native.truncate.call(this,physicalSize(next));cache.delete(state);state.size=next;state.cursor=Math.min(state.cursor,next);syncHeader(this,state);};
    AP.flush=function(){const state=accessState(this);if(!state.readonly&&!state.initialised)syncHeader(this,state);return native.flush.call(this);};
    AP.close=function(){const state=accesses.get(this);if(!state)return native.close.call(this);if(state.closed)return;state.closed=true;cache.delete(state);active.delete(this);return native.close.call(this);};
  }
  else if(native.sync)FP.createSyncAccessHandle=function(){return Promise.reject(failure('Synchronous private files require a dedicated worker','NotSupportedError'));};

  async function snapshot(handle,context){assert(context);const file=await native.getFile.call(handle);assert(context);const state=file.size?readHeader(context,new Uint8Array(await file.slice(0,HEADER).arrayBuffer())):{size:0,salt:random(16)};if(file.size&&file.size<physicalSize(state.size))throw failure('Incomplete encrypted file','NotReadableError');return {file,state};}
  // WasmFS reads a File snapshot in small slices. Reuse the last verified
  // block within that immutable snapshot; mutable writers still get fresh
  // blocks. The existing cache stays bounded and is wiped on sign-out.
  async function asyncBlock(file,context,state,index,cacheSnapshot=false){
    assert(context);if(index>=Math.ceil(state.size/BLOCK))return new Uint8Array(BLOCK);
    if(cacheSnapshot){const hit=cacheGet(state,index);if(hit)return hit;}
    const at=HEADER+index*SLOT,raw=new Uint8Array(await file.slice(at,at+SLOT).arrayBuffer());assert(context);
    const block=decodeBlock(context,state,index,raw);if(cacheSnapshot)cachePut(state,index,block);return block;
  }
  function virtualFile(file,context,state,start=0,end=state.size,name='',type=''){
    // Keep a native File snapshot, but decrypt slices and streams lazily. The
    // wasm engine asks for .size first and reads its packs in small slices.
    class PrivateFile extends File{
      constructor(){super([],name,{type,lastModified:file.lastModified});}
      get size(){assert(context);return end-start;}
      slice(a=0,b=end-start,mime=''){const len=end-start,offset=v=>Math.min(len,Math.max(0,v<0?len+Math.trunc(v):Math.trunc(v)||0)),from=offset(Number(a)),to=Math.max(from,offset(Number(b)));return virtualFile(file,context,state,start+from,start+to,name,String(mime).toLowerCase());}
      stream(){let at=start;return new ReadableStream({async pull(controller){try{assert(context);if(at>=end){controller.close();return;}const index=Math.floor(at/BLOCK),offset=at%BLOCK,block=await asyncBlock(file,context,state,index,true),n=Math.min(BLOCK-offset,end-at);assert(context);controller.enqueue(block.slice(offset,offset+n));at+=n;}catch(error){controller.error(error);}}});}
      async arrayBuffer(){const value=new Uint8Array(this.size),reader=this.stream().getReader();let at=0;for(;;){const {done,value:part}=await reader.read();if(done)break;value.set(part,at);at+=part.length;}return value.buffer;}
      async bytes(){return new Uint8Array(await this.arrayBuffer());}
      async text(){return new TextDecoder().decode(await this.arrayBuffer());}
    }
    return new PrivateFile();
  }
  FP.getFile=async function(){const meta=info(this),{file,state}=await snapshot(this,meta.context);return virtualFile(file,meta.context,state,0,state.size,meta.path.at(-1)||'');};

  if(native.writable)FP.createWritable=async function(options={}){
    const target=this,meta=info(target),context=meta.context;
    // Staging files live outside the website's exposed root. Committing a
    // native encrypted File keeps close()/abort() atomic without retaining a
    // multi-gigabyte game file in JS memory.
    const staging=await native.dir.call(meta.writerRoot.user,'.writers-'+meta.writerRoot.name,{create:true}),tempName=Array.from(random(16),b=>b.toString(16).padStart(2,'0')).join(''),temp=await native.file.call(staging,tempName,{create:true});
    let cursor=0;
    async function edit(operation){assert(context);const {file,state}=await snapshot(temp,context),writer=await native.writable.call(temp,{keepExistingData:true});try{
      const put=(index,block)=>writer.write({type:'write',position:HEADER+index*SLOT,data:encodeBlock(context,state,index,block)});
      if(operation.type==='truncate'){const next=size(operation.size);if(next<state.size&&next%BLOCK){const index=Math.floor(next/BLOCK),block=await asyncBlock(file,context,state,index);block.fill(0,next%BLOCK);await put(index,block);}if(next>state.size)for(let index=Math.ceil(state.size/BLOCK);index<Math.ceil(next/BLOCK);index++)await put(index,new Uint8Array(BLOCK));await writer.truncate(physicalSize(next));state.size=next;cursor=Math.min(cursor,next);}
      else{const input=operation.data,at=size(operation.position??cursor);size(at+input.length);if(input.length)for(let index=Math.ceil(state.size/BLOCK);index<Math.floor(at/BLOCK);index++)await put(index,new Uint8Array(BLOCK));let done=0;while(done<input.length){const index=Math.floor((at+done)/BLOCK),offset=(at+done)%BLOCK,n=Math.min(BLOCK-offset,input.length-done),block=await asyncBlock(file,context,state,index);block.set(input.subarray(done,done+n),offset);await put(index,block);done+=n;}if(done)state.size=Math.max(state.size,at+done);cursor=at+done;}
      await writer.write({type:'write',position:0,data:headerFor(context,state)});assert(context);await writer.close();
    }catch(error){await writer.abort().catch(()=>{});throw error;}}
    async function clean(){await native.remove.call(staging,tempName).catch(()=>{});}
    try{if(options.keepExistingData){const old=await native.getFile.call(target),writer=await native.writable.call(temp);try{assert(context);if(old.size)await writer.write(old);await writer.close();}catch(error){await writer.abort().catch(()=>{});throw error;}}}catch(error){await clean();throw error;}
    const sink={
      async write(value){if(value&&typeof value==='object'&&'type'in value){if(value.type==='seek'){cursor=size(value.position);return;}if(value.type==='truncate'){await edit({type:'truncate',size:value.size});return;}if(value.type==='write'){let data=value.data;data=typeof data==='string'?utf8.encode(data):data instanceof Blob?new Uint8Array(await data.arrayBuffer()):bytes(data);await edit({type:'write',data,position:value.position});return;}throw new TypeError('Invalid file stream command');}const data=typeof value==='string'?utf8.encode(value):value instanceof Blob?new Uint8Array(await value.arrayBuffer()):bytes(value);await edit({type:'write',data});},
      async close(){const source=await native.getFile.call(temp),writer=await native.writable.call(target);try{assert(context);await writer.write(source);assert(context);await writer.close();}catch(error){await writer.abort().catch(()=>{});throw error;}finally{await clean();}},
      async abort(){await clean();}
    };
    const stream=new WritableStream(sink);
    // FileSystemWritableFileStream's convenience methods coexist with the
    // standard getWriter()/pipeTo() interfaces.
    stream.write=value=>{let writer;try{assert(context);writer=stream.getWriter();return writer.write(value);}catch(error){return Promise.reject(error);}finally{writer?.releaseLock();}};
    stream.seek=position=>stream.write({type:'seek',position});
    stream.truncate=value=>stream.write({type:'truncate',size:value});
    return stream;
  };
  function clear(){for(const handle of active){const state=accesses.get(handle);state.closed=true;try{native.close.call(handle);}catch{}}active.clear();for(const entry of cache.values())for(const block of entry.values())block.fill(0);cache.clear();}
  return {bind,directory,clear};
}
