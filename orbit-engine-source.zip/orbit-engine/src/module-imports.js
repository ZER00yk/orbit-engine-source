// Scramjet 1.1.0 does not rewrite dynamic import() calls that are nested in
// function bodies. This small scanner handles the syntax we need without
// pulling a parser into the browser bundle. It deliberately treats template
// literals as strings; a template expression is not a module import location.
const identifier = value => !!value && /[A-Za-z0-9_$]/.test(value);

function skipQuoted(source,index,quote){
  for(let i=index+1;i<source.length;i++){
    const value=source[i];
    if(value==='\\'){i++;continue;}
    if(value===quote)return i+1;
  }
  return source.length;
}

function skipComment(source,index){
  if(source[index+1]==='/'){
    const end=source.indexOf('\n',index+2);
    return end<0?source.length:end+1;
  }
  const end=source.indexOf('*/',index+2);
  return end<0?source.length:end+2;
}

function skipSpaceAndComments(source,index){
  let cursor=index;
  while(cursor<source.length){
    if(/\s/.test(source[cursor])){cursor++;continue;}
    if(source[cursor]==='/'&&(source[cursor+1]==='/'||source[cursor+1]==='*')){cursor=skipComment(source,cursor);continue;}
    break;
  }
  return cursor;
}

function closeCall(source,open){
  let depth=1;
  for(let i=open+1;i<source.length;i++){
    const value=source[i];
    if(value==='"'||value==="'"||value==='`'){i=skipQuoted(source,i,value)-1;continue;}
    if(value==='/'&&(source[i+1]==='/'||source[i+1]==='*')){i=skipComment(source,i)-1;continue;}
    if(value==='('||value==='['||value==='{'){depth++;continue;}
    if(value===')'){
      depth--;
      if(depth===0)return i;
      continue;
    }
    if(value===']'||value==='}')depth=Math.max(0,depth-1);
  }
  return -1;
}

export function rewriteDynamicImports(source,address,helper){
  const code=typeof source==='string'?source:new TextDecoder().decode(source);
  if(!code.includes('import'))return source;
  const edits=[];
  for(let i=0;i<code.length;){
    const value=code[i];
    if(value==='"'||value==="'"||value==='`'){i=skipQuoted(code,i,value);continue;}
    if(value==='/'&&(code[i+1]==='/'||code[i+1]==='*')){i=skipComment(code,i);continue;}
    if(code.startsWith('import',i)&&!identifier(code[i-1])&&!identifier(code[i+6])){
      const open=skipSpaceAndComments(code,i+6);
      if(code[open]==='('){
        const close=closeCall(code,open);
        if(close>=0){edits.push({start:i,end:open+1});i=open+1;continue;}
      }
    }
    i++;
  }
  if(!edits.length)return source;
  let result=code;
  const prefix=helper+'('+JSON.stringify(address)+',';
  for(let i=edits.length-1;i>=0;i--){const edit=edits[i];result=result.slice(0,edit.start)+prefix+result.slice(edit.end);}
  return result;
}
