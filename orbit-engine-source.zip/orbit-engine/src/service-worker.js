function withTimeout(promise,message,timeoutMs){
  let timer;
  const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(message)),timeoutMs);});
  return Promise.race([promise,timeout]).finally(()=>clearTimeout(timer));
}

export async function prepareServiceWorker(serviceWorkers,timeoutMs=15000,script='/sw.js'){
  const registration=await withTimeout(
    serviceWorkers.register(script,{scope:'/',updateViaCache:'none'}),
    'The browsing engine couldn’t start. Reload Orbit to try again.',timeoutMs,
  );
  await withTimeout(serviceWorkers.ready,'The browsing engine is taking too long to start. Reload Orbit to try again.',timeoutMs);
  const scriptMatches=()=>!registration.active?.scriptURL||registration.active.scriptURL.endsWith(script);
  const controlled=()=>serviceWorkers.controller&&serviceWorkers.controller===registration.active&&scriptMatches();
  if(controlled())return registration;
  // ready means a worker is active; it does not mean this page is controlled yet.
  await new Promise((resolve,reject)=>{
    const changed=()=>{if(controlled()){cleanup();resolve();}};
    const timer=setTimeout(()=>{cleanup();reject(new Error('The browsing engine couldn’t take control. Open Orbit in Chrome or Firefox and reload.'));},timeoutMs);
    const cleanup=()=>{clearTimeout(timer);serviceWorkers.removeEventListener('controllerchange',changed);};
    serviceWorkers.addEventListener('controllerchange',changed);
    changed();
  });
  return registration;
}
