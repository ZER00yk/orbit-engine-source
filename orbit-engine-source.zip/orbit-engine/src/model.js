export const STORAGE_KEY='orbit.browsing.v1';
export const SEARCH_ENGINES={google:'https://www.google.com/search?q=',duckduckgo:'https://duckduckgo.com/?q=',bing:'https://www.bing.com/search?q='};
export function resolveAddress(value,engine='google') {
  const input=String(value).trim();
  if(!input)throw new Error('Enter a website or search.');
  if(/^https?:/i.test(input) || /^[a-z][a-z\d+.-]*:\/\//i.test(input) || /^(?:javascript|data|file|blob|ftp|about|vbscript):/i.test(input)) {
    const url=new URL(input);
    if(!['http:','https:'].includes(url.protocol))throw new Error('Use an http or https website address.');
    if(url.username || url.password)throw new Error('Use a website address without a username or password.');
    return url.href;
  }
  if(!/\s/.test(input) && (/^[\w-]+(?:\.[\w-]+)+(?:[/:?#]|$)/.test(input) || /^localhost(?::\d+)?(?:\/|$)/i.test(input)))return new URL('https://'+input).href;
  return (SEARCH_ENGINES[engine]||SEARCH_ENGINES.google)+encodeURIComponent(input);
}
export function freshState() {
  // Tab IDs do not require the HTTPS-only randomUUID API.
  const bytes=crypto.getRandomValues(new Uint8Array(16));
  const id=Array.from(bytes,value=>value.toString(16).padStart(2,'0')).join('');
  return {version:1,tabs:[{id,url:'',title:'New tab',trail:[],position:-1}],activeId:null,bookmarks:[],history:[],engine:'google',relay:''};
}
export function restoreState(storage) {
  const fallback=freshState();
  try {
    const saved=JSON.parse(storage.getItem(STORAGE_KEY));
    if(!saved || saved.version!==1 || !Array.isArray(saved.tabs))return fallback;
    const tabs=saved.tabs.filter(t=>t && typeof t.id==='string' && typeof t.url==='string').slice(0,20).map(t=>{const trail=Array.isArray(t.trail)?t.trail.filter(validUrl).slice(-100):[];return {id:t.id,url:validUrl(t.url)?t.url:'',title:String(t.title||'New tab').slice(0,180),trail,position:Math.max(-1,Math.min(Number.isInteger(t.position)?t.position:-1,trail.length-1))};});
    return {version:1,tabs:tabs.length?tabs:fallback.tabs,activeId:saved.activeId,bookmarks:validEntries(saved.bookmarks,200),history:validEntries(saved.history,500),engine:SEARCH_ENGINES[saved.engine]?saved.engine:'google',relay:validRelay(saved.relay)?saved.relay:''};
  } catch{return fallback;}
}
function validEntries(entries,max) {return Array.isArray(entries)?entries.filter(x=>x && validUrl(x.url)).slice(0,max).map(x=>({url:x.url,title:String(x.title||new URL(x.url).hostname).slice(0,180),time:Number(x.time)||Date.now()})):[];}
export function validUrl(value) {try{return ['http:','https:'].includes(new URL(value).protocol);}catch{return false;}}
export function validRelay(value) {try{const u=new URL(value);return u.protocol==='wss:' && !u.username && !u.password;}catch{return false;}}
export function recordVisit(state,tab,url,title=tab.title,{recordHistory=true}={}) {
  if(!validUrl(url))return;
  if(tab.url!==url || !tab.trail.length) {
    tab.trail=tab.trail.slice(0,tab.position+1);
    if(tab.trail.at(-1)!==url)tab.trail.push(url);
    if(tab.trail.length>100)tab.trail.shift();
    tab.position=tab.trail.length-1;
  }
  tab.url=url;tab.title=title||new URL(url).hostname;
  if(!recordHistory)return;
  state.history=state.history.filter(entry=>entry.url!==url);
  state.history.unshift({url,title:tab.title,time:Date.now()});
  state.history=state.history.slice(0,500);
}
