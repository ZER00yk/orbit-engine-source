import {gcm} from '@noble/ciphers/aes.js';
import {createProfileFiles} from './profile-files.js';
import {rewriteDynamicImports} from './module-imports.js';
const utf8=new TextEncoder(),text=new TextDecoder();
let profile=null,key=null;
const nativeLocal=globalThis.localStorage,nativeSession=globalThis.sessionStorage;
function b64(bytes){let value='';for(let i=0;i<bytes.length;i+=8192)value+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(value).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');}
function unb64(value){return Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/')),x=>x.charCodeAt(0));}
function ensure(){if(!profile||!key)throw new Error('A signed-in browsing profile is required.');}
const privateFiles=createProfileFiles(()=>{ensure();return {id:profile.id,bytes:key};});
function seal(value,scope){ensure();const nonce=crypto.getRandomValues(new Uint8Array(12));const cipher=gcm(key,nonce,utf8.encode(profile.id+':'+scope)).encrypt(utf8.encode(JSON.stringify(value)));const bytes=new Uint8Array(nonce.length+cipher.length);bytes.set(nonce);bytes.set(cipher,12);return 'v1.'+b64(bytes);}
function open(value,scope){ensure();if(typeof value!=='string'||!value.startsWith('v1.'))return null;const bytes=unb64(value.slice(3));return JSON.parse(text.decode(gcm(key,bytes.slice(0,12),utf8.encode(profile.id+':'+scope)).decrypt(bytes.slice(12))));}
const dbName=name=>{ensure();return 'orbit:'+profile.id+':'+name;};
const visibleDBName=name=>{ensure();const prefix='orbit:'+profile.id+':';return name.startsWith(prefix)?name.slice(prefix.length).replace(/^https?:\/\/[^@]+@/,''):name;};
function storageHandler(host,session=false){
  ensure();const native=session?nativeSession:nativeLocal,prefix='orbit:'+profile.id+':storage:'+host+'@',scope='storage:'+host;
  const names=()=>Object.keys(native).filter(x=>x.startsWith(prefix)).map(x=>x.slice(prefix.length));
  const get=name=>{const value=native.getItem(prefix+String(name));if(value===null)return null;try{return open(value,scope+':'+String(name));}catch{return null;}};
  const set=(name,value)=>{native.setItem(prefix+String(name),seal(String(value),scope+':'+String(name)));};
  const remove=name=>native.removeItem(prefix+String(name));
  return {get(target,name){
    if(name==='getItem')return get;if(name==='setItem')return set;if(name==='removeItem')return remove;
    if(name==='clear')return()=>names().forEach(remove);if(name==='key')return i=>names()[Number(i)]??null;if(name==='length')return names().length;
    if(typeof name==='symbol'||name in Object.prototype)return Reflect.get(target,name);return get(name);
  },set(target,name,value){set(name,value);return true;},deleteProperty(target,name){remove(name);return true;},has(target,name){return typeof name==='string'&&names().includes(name);},ownKeys(){return names();},getOwnPropertyDescriptor(target,name){const value=get(name);return value===null?undefined:{value,enumerable:true,writable:true,configurable:true};},defineProperty(target,name,descriptor){if('value'in descriptor)set(name,descriptor.value);return true;}};
}
// Encrypt game records while retaining the keys required by IndexedDB indexes.
// Cookies use a separately encrypted jar. Public index keys remain searchable.
const DB=globalThis.IDBDatabase,Store=globalThis.IDBObjectStore,Request=globalThis.IDBRequest,Cursor=globalThis.IDBCursorWithValue;
const dbGetter=DB&&Object.getOwnPropertyDescriptor(DB.prototype,'name')?.get;
function sourceStore(source){return source?.objectStore||source;}
function scopeFor(store){try{const name=dbGetter.call(store.transaction.db);return profile&&name.startsWith(dbName(''))&&!name.endsWith(':$scramjet')?'idb:'+name+':'+store.name:null;}catch{return null;}}
function serialise(value){
  if(value===undefined)return {t:'undefined'};
  if(typeof value==='bigint')return {t:'bigint',v:String(value)};
  if(value instanceof Date)return {t:'date',v:value.toISOString()};
  if(value instanceof ArrayBuffer)return {t:'bytes',v:b64(new Uint8Array(value))};
  if(ArrayBuffer.isView(value))return {t:'typed',n:value.constructor.name,v:b64(new Uint8Array(value.buffer,value.byteOffset,value.byteLength))};
  if(value instanceof Map)return {t:'map',v:[...value].map(([k,v])=>[serialise(k),serialise(v)])};
  if(value instanceof Set)return {t:'set',v:[...value].map(serialise)};
  if(Array.isArray(value))return {t:'array',v:value.map(serialise)};
  if(value&&typeof value==='object'){
    if(typeof Blob!=='undefined'&&value instanceof Blob)throw new DOMException('Blob records are not supported in private IndexedDB.','DataCloneError');
    return {t:'object',v:Object.keys(value).map(k=>[k,serialise(value[k])])};
  }return {t:'value',v:value};
}
function deserialise(node){
  switch(node.t){case'undefined':return undefined;case'bigint':return BigInt(node.v);case'date':return new Date(node.v);case'bytes':return unb64(node.v).buffer;case'typed':{const bytes=unb64(node.v);const Type=globalThis[node.n];return new Type(bytes.buffer);}case'map':return new Map(node.v.map(([k,v])=>[deserialise(k),deserialise(v)]));case'set':return new Set(node.v.map(deserialise));case'array':return node.v.map(deserialise);case'object':return Object.fromEntries(node.v.map(([k,v])=>[k,deserialise(v)]));default:return node.v;}
}
function copyPath(from,to,path){
  if(typeof path!=='string'||!path)return;const parts=path.split('.');let input=from,output=to;
  for(let i=0;i<parts.length;i++){const p=parts[i];if(!input||!Object.hasOwn(input,p))return;if(i===parts.length-1){Object.defineProperty(output,p,{value:input[p],writable:true,enumerable:true,configurable:true});return;}input=input[p];if(!Object.hasOwn(output,p))Object.defineProperty(output,p,{value:{},enumerable:true,writable:true,configurable:true});output=output[p];}
}
function encodeRecord(store,value){const scope=scopeFor(store);if(!scope)return value;const result={__orbit_private_record:seal(serialise(value),scope)};const paths=[store.keyPath,...Array.from(store.indexNames,name=>store.index(name).keyPath)].flat();for(const path of paths)copyPath(value,result,path);return result;}
function decodeRecord(store,value){const scope=scopeFor(store);if(!scope)return value;if(Array.isArray(value))return value.map(v=>decodeRecord(store,v));if(value&&typeof value.__orbit_private_record==='string')return deserialise(open(value.__orbit_private_record,scope));return value;}
if(Store&&Request&&Cursor){
  for(const method of ['put','add']){const native=Store.prototype[method];Store.prototype[method]=function(value,...args){return native.call(this,encodeRecord(this,value),...args);};}
  const update=globalThis.IDBCursor.prototype.update;globalThis.IDBCursor.prototype.update=function(value){return update.call(this,encodeRecord(sourceStore(this.source),value));};
  const result=Object.getOwnPropertyDescriptor(Request.prototype,'result');Object.defineProperty(Request.prototype,'result',{...result,get(){return decodeRecord(sourceStore(this.source),result.get.call(this));}});
  const value=Object.getOwnPropertyDescriptor(Cursor.prototype,'value');Object.defineProperty(Cursor.prototype,'value',{...value,get(){return decodeRecord(sourceStore(this.source),value.get.call(this));}});
}
// Response bodies and headers in CacheStorage can contain account data too.
if(globalThis.CacheStorage&&globalThis.Cache){
  const cacheNames=new WeakMap(),CP=Cache.prototype,SP=CacheStorage.prototype;
  const original={open:SP.open,keys:SP.keys,delete:SP.delete,has:SP.has,match:CP.match,matchAll:CP.matchAll,put:CP.put};
  const prefix=()=>dbName('cache:');
  const requestUrl=request=>typeof request==='string'?new URL(request,globalThis.location.href).href:request.url;
  SP.open=async function(name){const scoped=prefix()+String(name),cache=await original.open.call(this,scoped);cacheNames.set(cache,scoped);return cache;};
  SP.keys=async function(){return (await original.keys.call(this)).filter(n=>n.startsWith(prefix())).map(n=>n.slice(prefix().length));};
  SP.delete=function(name){return original.delete.call(this,prefix()+String(name));};
  SP.has=function(name){return original.has.call(this,prefix()+String(name));};
  CP.put=async function(request,response){const name=cacheNames.get(this);if(!name)return original.put.call(this,request,response);const body=new Uint8Array(await response.clone().arrayBuffer());const value={status:response.status,statusText:response.statusText,headers:[...response.headers],body:b64(body)};return original.put.call(this,request,new Response(seal(value,'cache:'+name+':'+requestUrl(request)),{headers:{'Content-Type':'application/octet-stream','X-Orbit-Private-Cache':'1'}}));};
  async function decode(cache,request,response){if(!response||response.headers.get('X-Orbit-Private-Cache')!=='1')return response;const value=open(await response.text(),'cache:'+cacheNames.get(cache)+':'+requestUrl(request));return new Response([204,205,304].includes(value.status)?null:unb64(value.body),{status:value.status,statusText:value.statusText,headers:value.headers});}
  CP.match=async function(request,options){return decode(this,request,await original.match.call(this,request,options));};
  CP.matchAll=async function(request,options){const matches=await original.matchAll.call(this,request,options);if(!request){const requests=await this.keys();return Promise.all(matches.map((r,i)=>decode(this,requests[i],r)));}return Promise.all(matches.map(r=>decode(this,request,r)));};
  CP.add=async function(request){const response=await fetch(request);if(!response.ok)throw new TypeError('Cache response failed');await this.put(request,response);};
  CP.addAll=async function(requests){const responses=await Promise.all(requests.map(r=>fetch(r)));if(responses.some(r=>!r.ok))throw new TypeError('Cache response failed');await Promise.all(responses.map((r,i)=>this.put(requests[i],r)));};
  SP.match=async function(request,options={}){const names=options.cacheName?[options.cacheName]:await this.keys();for(const name of names){const cache=await this.open(name),response=await cache.match(request,options);if(response)return response;}};
}
globalThis.OrbitProfile={
  configure(context){if(!context||!/^[-\w]{43}$/.test(context.id)||!/^[-\w]{43}$/.test(context.key))throw new Error('Invalid browsing profile');if(profile){if(profile.id!==context.id||profile.key!==context.key)throw new Error('The browsing account changed. Reload this profile.');return;}profile={id:context.id,key:context.key};key=unb64(context.key);},
  dbName,visibleDBName,storageHandler,seal,open,
  rewriteJS(source,address,helper){ensure();return rewriteDynamicImports(source,address,helper);},
  filesOrigin(origin){privateFiles.bind(origin);},filesDirectory(origin){return privateFiles.directory(origin);},
  bootstrap(){ensure();return 'globalThis.OrbitProfile.configure('+JSON.stringify(profile)+');';},
  cookieDump(value){return open(value,'cookies')||{};},cookieSeal(value){return seal(value,'cookies');},
  current(){ensure();return {...profile};},
  clearMemory(){privateFiles.clear?.();key?.fill(0);profile=null;key=null;},
};
