import {prepareServiceWorker} from './service-worker.js';
let appOrigin,context,controller,frame,connection,started=false,relay;
const channel=location.hash.slice(1);
const send=data=>parent.postMessage({...data,channel},appOrigin);
const status=document.getElementById('engine-status');
const openLink=document.getElementById('engine-open');
function startupError(error){
  status.hidden=false;status.textContent=error.message||'Your browsing profile couldn’t start. Open Orbit and try again.';
  openLink.hidden=false;
  if(appOrigin&&parent!==window&&/^[a-f0-9-]{36}$/.test(channel))send({type:'error',message:status.textContent});
}
async function openProfile(){
const response=await fetch('/api/config',{cache:'no-store',signal:AbortSignal.timeout(10000)});
if(!response.ok)throw new Error('Orbit couldn’t load its browsing settings. Try opening Orbit again.');
const config=await response.json(),app=new URL(config.app);
if(app.protocol!=='https:'||app.origin!==config.app)throw new Error('Orbit’s browsing settings are unavailable.');
appOrigin=app.origin;openLink.href=appOrigin;
// The engine is a child of the account page, not a separate sign-in page.
// Opening its published link directly must return to Orbit, never wait for a
// parent window that does not exist.
if(parent===window){status.textContent='Opening Orbit…';location.replace(appOrigin);return;}
if(!/^[a-f0-9-]{36}$/.test(channel))throw new Error('Open this browsing profile from Orbit.');
openLink.hidden=true;
async function bootstrap(ticket){const response=await fetch('/api/bootstrap',{method:'POST',headers:{'X-Orbit-Ticket':ticket},credentials:'include',cache:'no-store',signal:AbortSignal.timeout(15000)});if(!response.ok)throw Object.assign(new Error(response.status===401?'Your browsing connection needs to be renewed. Try again.':'Your browsing connection is temporarily unavailable. Try again.'),{status:response.status});return response.json();}
function stopped(){started=false;frame?.frame.remove();frame=null;status.textContent='Signed out';window.OrbitProfile.clearMemory();}
const accounts=new BroadcastChannel('orbit-engine-account');accounts.onmessage=event=>{if(context&&event.data?.id!==context.id){stopped();send({type:'session-expired'});}};
async function start(ticket,policy){
  if(!window.isSecureContext||!navigator.serviceWorker)throw new Error('Open Orbit in a regular, secure browser tab to start browsing.');
  const profile=await bootstrap(ticket);context=profile;window.OrbitProfile.configure(profile);accounts.postMessage({id:profile.id});
  // A different account gets a new worker realm. Old cookie jars and pending
  // responses cannot be re-encrypted with the next account’s profile key.
  const registration=await prepareServiceWorker(navigator.serviceWorker,15000,'/api/runtime/sw.js?v=11&profile='+profile.id);
  await new Promise((resolve,reject)=>{const message=new MessageChannel(),timer=setTimeout(()=>reject(new Error('Your private browsing profile couldn’t start.')),15000);message.port1.onmessage=e=>{clearTimeout(timer);e.data.ok?resolve():reject(new Error(e.data.error||'Your profile couldn’t start.'));};navigator.serviceWorker.controller.postMessage({type:'orbit-profile-ready'},[message.port2]);});
  const {ScramjetController}=window.$scramjetLoadController();
  // Normal asynchronous browsing and libcurl do not require shared memory.
  // Keep the optional synchronous-XHR path disabled; games can use shared
  // WebAssembly memory independently of that legacy request feature.
  controller=new ScramjetController({prefix:'/browse/',files:{wasm:'/scram/scramjet.wasm.wasm',all:'/scram/scramjet.all.js?v=2.0.0-orbit.8',sync:'/scram/scramjet.sync.js'},flags:{syncxhr:false,interceptDownloads:true,captureErrors:false,cleanErrors:false,sourcemaps:false}});
  await controller.init();await controller.modifyConfig(policy||{});
  connection=new window.BareMux.BareMuxConnection('/api/runtime/connection.js');relay=policy?.orbitRelay||new URL('/wisp/',location.origin).href.replace(/^https:/,'wss:');await connection.setTransport('/transport.mjs?v=4',[{websocket:relay}]);
  frame=controller.createFrame();frame.frame.setAttribute('allow','cross-origin-isolated; fullscreen; autoplay; clipboard-read; clipboard-write; gamepad');frame.frame.setAttribute('allowfullscreen','');document.getElementById('engine-frames').append(frame.frame);
  frame.addEventListener('navigate',event=>send({type:'navigate',url:String(event.url||'')}));frame.addEventListener('urlchange',event=>send({type:'urlchange',url:String(event.url)}));
  frame.addEventListener('orbit-open-tab',event=>send({type:'open-tab',url:event.url}));
  frame.frame.addEventListener('load',()=>{
    let title='';try{const doc=frame.frame.contentDocument;title=doc?.title||'';doc?.addEventListener('keydown',event=>{const key=event.key,shortcut=((event.ctrlKey||event.metaKey)&&['k','f'].includes(key.toLowerCase()))||event.altKey&&['ArrowLeft','ArrowRight'].includes(key)||key==='Escape';if(shortcut)send({type:'key',key:{key,ctrlKey:event.ctrlKey,metaKey:event.metaKey,shiftKey:event.shiftKey,altKey:event.altKey}});},{capture:true});}catch{}
    status.hidden=true;send({type:'loaded',title});
  });
  window.__orbitGameDiagnostics=(source,report)=>{if(source===frame?.frame.contentWindow)send({type:'diagnostics',report});};
  navigator.serviceWorker.addEventListener('message',event=>{if(event.source===navigator.serviceWorker.controller&&['orbit-site-challenge','orbit-youtube-restricted','orbit-roblox-recovery-blocked','orbit-google-signin','orbit-google-denied','orbit-adblock-blocked'].includes(event.data?.type))send({type:'notice',notice:event.data});});
  controller.addEventListener('download',async event=>{try{const blob=await new Response(event.download.body).blob(),href=URL.createObjectURL(blob),link=document.createElement('a');link.href=href;link.download=event.download.filename||'download';link.click();setTimeout(()=>URL.revokeObjectURL(href),60000);}catch{send({type:'error',message:'The download couldn’t finish.'});}});
  started=true;send({type:'started'});
}
async function check(){return new Promise(resolve=>{let socket,timer,done=false;const finish=ok=>{if(done)return;done=true;clearTimeout(timer);socket?.close();resolve(ok);};try{socket=new WebSocket(relay);socket.binaryType='arraybuffer';socket.onmessage=e=>{const bytes=new Uint8Array(e.data);if(bytes.length>=5&&[3,5].includes(bytes[0]))finish(true);};socket.onerror=()=>finish(false);socket.onclose=()=>finish(false);timer=setTimeout(()=>finish(false),12000);}catch{finish(false);}});}
async function clear(){
  frame?.frame.remove();frame=null;const prefix=window.OrbitProfile.dbName('');
  for(const name of Object.keys(localStorage))if(name.startsWith(prefix))localStorage.removeItem(name);
  for(const name of Object.keys(sessionStorage))if(name.startsWith(prefix))sessionStorage.removeItem(name);
  if(indexedDB.databases)for(const entry of await indexedDB.databases())if(entry.name?.startsWith(prefix)&&entry.name!==OrbitProfile.dbName('$scramjet'))await new Promise((resolve,reject)=>{const r=indexedDB.deleteDatabase(entry.name);r.onsuccess=resolve;r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('Close other Orbit tabs, then try clearing your data again.'));});
  const db=await controller.openIDB();try{await db.put('cookies',OrbitProfile.cookieSeal({}),'cookies');}finally{db.close();}
  if(globalThis.caches)for(const name of await caches.keys())await caches.delete(name);
  await refreshJar();
  return true;
}
const idbResult=request=>new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
async function refreshJar(){const message=new MessageChannel();await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Website cookies could not be activated yet')),10000);message.port1.onmessage=e=>{clearTimeout(timer);e.data.ok?resolve():reject(new Error(e.data.error));};navigator.serviceWorker.controller.postMessage({type:'orbit-profile-ready',reloadCookies:true},[message.port2]);});}
async function importLegacy(data){
  if(!data||!Array.isArray(data.local)||!Array.isArray(data.databases)||data.local.length>50000||data.databases.length>100)throw new Error('Invalid existing game data');
  for(const [name,value] of data.local){const at=name.indexOf('@');if(at<1||typeof value!=='string')continue;const host=name.slice(0,at),item=name.slice(at+1);OrbitProfile.storageHandler(host).get({},'setItem')(item,value);}
  const cookieDb=await controller.openIDB();try{await cookieDb.put('cookies',OrbitProfile.cookieSeal(data.cookies||{}),'cookies');}finally{cookieDb.close();}
  for(const info of data.databases){
    if(!/^https?:\/\//.test(info.name)||!Array.isArray(info.stores))continue;
    const request=indexedDB.open(OrbitProfile.dbName(info.name),info.version);request.onupgradeneeded=()=>{const db=request.result;for(const store of info.stores){if(db.objectStoreNames.contains(store.name))continue;const objectStore=db.createObjectStore(store.name,{keyPath:store.keyPath,autoIncrement:store.autoIncrement});for(const index of store.indexes)objectStore.createIndex(index.name,index.keyPath,{unique:index.unique,multiEntry:index.multiEntry});}};
    const db=await idbResult(request);try{
      for(const store of info.stores){const transaction=db.transaction(store.name,'readwrite'),objectStore=transaction.objectStore(store.name),done=new Promise((resolve,reject)=>{transaction.oncomplete=resolve;transaction.onerror=()=>reject(transaction.error);transaction.onabort=()=>reject(transaction.error);});for(let i=0;i<store.records.length;i++)store.keyPath===null?objectStore.put(store.records[i],store.keys[i]):objectStore.put(store.records[i]);await done;}
    }finally{db.close();}
  }
  // Reload the worker jar from the encrypted import before opening a game.
  await refreshJar();
  return true;
}
window.addEventListener('message',async event=>{
  if(event.origin!==appOrigin||event.source!==parent||event.data?.channel!==channel)return;const data=event.data;
  try{
    if(data.type==='init'&&!started)await start(data.ticket,data.config);
    if(data.type==='refresh'&&started){const profile=await bootstrap(data.ticket);if(profile.id!==context?.id){stopped();send({type:'session-expired'});return;}}
    if(data.type==='go'&&started&&typeof data.url==='string'&&/^https?:\/\//.test(data.url))frame.go(data.url);
    if(data.type==='reload'&&started)frame.reload();
    if(data.type==='policy'&&controller){await controller.modifyConfig(data.config);const next=data.config?.orbitRelay||new URL('/wisp/',location.origin).href.replace(/^https:/,'wss:');if(next!==relay){relay=next;await connection.setTransport('/transport.mjs?v=4',[{websocket:relay}]);}}
    if(data.type==='stop'){stopped();return;}
    if(data.type==='check')send({type:'reply',id:data.id,result:await check()});
    if(data.type==='clear-profile')send({type:'reply',id:data.id,result:await clear()});
    if(data.type==='import-legacy')send({type:'reply',id:data.id,result:await importLegacy(data.data)});
  }catch(error){if(data.id)send({type:'reply',id:data.id,error:error.message});else if(!started)startupError(error);else if(data.type!=='refresh')send({type:'error',message:error.message});}
});
send({type:'ready'});
setInterval(async()=>{if(!started)return;try{const response=await fetch('/api/context',{cache:'no-store'});if(response.status===401){send({type:'renew-session'});return;}if(response.ok&&(await response.json()).id!==context?.id){stopped();send({type:'session-expired'});}}catch{}},60000);
}
openProfile().catch(startupError);
