import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {patchScramjetCookies} from '../scripts/scramjet-patches.mjs';

const upstream=await readFile(new URL('../node_modules/@mercuryworkshop/scramjet/dist/scramjet.all.js',import.meta.url),'utf8');
const site=new URL('https://pokedoku.com/'),api=new URL('https://api.pokedoku.com/api/puzzle/solution/guess');
function cookieClass(source){
  const context=vm.createContext({URL,TextEncoder,TextDecoder,Event,EventTarget,performance,atob,btoa,console});context.self=context;
  vm.runInContext(source.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='),context);
  return context.__testRequire(3831).k;
}

// Exercise the pinned response handler with its real cookie/event logic.
// Header rewriting, storage I/O, and page delivery are the external seams.
function responseHandler(source,{storageError}={}){
  const factory=source.match(/5790:function\(e,t,r\)\{([\s\S]*?)\},7510:function/);
  assert.ok(factory);
  const state={saved:undefined,writes:0,closes:0,warnings:[]};
  const modules={
    5956:{},8228:{},6684:{Sn:async()=>{}},1472:{},1478:{},1427:{},
    37:{$W:{prefix:'/browse/'},U5:()=>false},
    4435:{l:async headers=>({...headers})},884:{},2614:{},2015:{},8665:{A:{}},
    6570:{P2:async()=>({put:async(store,value,key)=>{if(storageError)throw storageError;assert.equal(store,'cookies');assert.equal(key,'cookies');state.saved=value;state.writes++;},close:()=>state.closes++})},
  };
  const require=id=>{assert.ok(id in modules);return modules[id];};require.d=(exports,definitions)=>{for(const[key,get]of Object.entries(definitions))Object.defineProperty(exports,key,{get});};
  const body=factory[1].replace('Pf:()=>m,V3:()=>S,dT:()=>w','Pf:()=>m,V3:()=>S,dT:()=>w,handleResponse:()=>y');
  const context=vm.createContext({URL,Event,Response,crossOriginIsolated:false,Array,console:{warn:message=>state.warnings.push(message)}});
  const exports={};vm.runInContext('(function(e,t,r){'+body+'})',context)({},exports,require);
  return {run:exports.handleResponse,state};
}
async function deliver(handler,workerJar,pageJar,cookies){
  const messages=[],worker=new EventTarget();
  worker.dispatch=async(client,message)=>{messages.push(message.cookie);pageJar.setCookies([message.cookie],new URL(message.url));};
  const payload={rawHeaders:{'content-type':'application/json','set-cookie':cookies},body:new TextEncoder().encode('{"result":true}'),status:200,statusText:'OK',finalURL:api.href};
  const response=await handler.run(api,{origin:api,base:api},'','','cors',payload,workerJar,{}, {},worker,'');
  assert.deepEqual(await response.json(),{result:true});
  return messages;
}

test('real upstream cookie restoration loses the IndexedDB object; the patch preserves it',()=>{
  for(const [source,expected]of [[upstream,''],[patchScramjetCookies(upstream),'session=original']]){
    const Store=cookieClass(source),before=new Store(),after=new Store();
    before.setCookies(['session=original; Domain=pokedoku.com; Path=/; Secure'],site);
    after.load(JSON.parse(before.dump()));assert.equal(after.getCookies(site,true),expected);
    const fromString=new Store();fromString.load(before.dump());assert.equal(fromString.getCookies(site,true),'session=original');
  }
});

test('real upstream response-cookie messages reproduce indices and missing persistence',async()=>{
  const Store=cookieClass(upstream),handler=responseHandler(upstream),workerJar=new Store(),pageJar=new Store();
  const messages=await deliver(handler,workerJar,pageJar,['session=first; Domain=pokedoku.com; Path=/','csrf=first; Domain=pokedoku.com; Path=/']);
  assert.deepEqual(messages,['0','1']);assert.equal(handler.state.saved,undefined);
  assert.equal(pageJar.getCookies(site,true).includes('session=first'),false);
});

test('twelve response-cookie rotations reach the page and survive a worker restart',async()=>{
  const patched=patchScramjetCookies(upstream),Store=cookieClass(patched),handler=responseHandler(patched),pageJar=new Store();
  let workerJar=new Store();
  for(let i=1;i<=12;i++){
    const cookies=[`session=guess-${i}; Domain=pokedoku.com; Path=/; Secure`,`auth=private-${i}; Domain=pokedoku.com; Path=/; Secure; HttpOnly`];
    assert.deepEqual(await deliver(handler,workerJar,pageJar,cookies),cookies);
    assert.equal(pageJar.getCookies(site,true),`session=guess-${i}`);
    workerJar=new Store();workerJar.load(handler.state.saved);
    assert.equal(workerJar.getCookies(api,false),`session=guess-${i}; auth=private-${i}`);
  }
  assert.equal(handler.state.writes,12);
});

test('a single response cookie is delivered once and stays within its domain',async()=>{
  const patched=patchScramjetCookies(upstream),Store=cookieClass(patched),handler=responseHandler(patched),workerJar=new Store(),pageJar=new Store();
  const cookie='session=current; Domain=pokedoku.com; Path=/; Secure';
  assert.deepEqual(await deliver(handler,workerJar,pageJar,cookie),[cookie]);
  assert.equal(workerJar.getCookies(new URL('https://sub.pokedoku.com/'),false),'session=current');
  assert.equal(workerJar.getCookies(new URL('https://fakepokedoku.com/'),false),'');
  assert.equal(workerJar.getCookies(new URL('http://pokedoku.com/'),false),'');
});

test('the cookie patch rejects an unexpected upstream bundle',()=>{
  assert.throws(()=>patchScramjetCookies('changed bundle'),/cookie implementation changed/);
});

test('a mixed legacy jar retains its session and ignores incomplete records instead of breaking fetch',()=>{
  const Store=cookieClass(patchScramjetCookies(upstream)),jar=new Store();
  jar.setCookies(['session=saved; Domain=pokedoku.com; Path=/; Secure'],site);
  const saved=JSON.parse(jar.dump());
  Object.assign(saved,{bad:null,index:{domain:'.pokedoku.com',path:'/'},missingDomain:{name:'broken',value:'x',path:'/'}});
  const restored=new Store();restored.load(saved);
  assert.equal(restored.getCookies(api,false),'session=saved');
  for(const invalid of [null,'null','{broken',[]]){
    restored.load(invalid);assert.equal(restored.getCookies(api,false),'session=saved');
  }
});

test('a cookie storage failure does not turn a successful game response into a failed download',async()=>{
  const patched=patchScramjetCookies(upstream),Store=cookieClass(patched),handler=responseHandler(patched,{storageError:new Error('Quota exceeded')});
  const workerJar=new Store(),pageJar=new Store(),cookie='session=current; Domain=pokedoku.com; Path=/; Secure';
  assert.deepEqual(await deliver(handler,workerJar,pageJar,cookie),[cookie]);
  assert.equal(workerJar.getCookies(api,false),'session=current');
  assert.equal(pageJar.getCookies(site,true),'session=current');
  assert.equal(handler.state.closes,1);assert.equal(handler.state.warnings.length,1);
});

test('cookie acknowledgements use the original service worker even if a page replaces its controller',()=>{
  const patched=patchScramjetCookies(upstream);
  const marker=patched.indexOf('ServiceWorkerContainer.prototype.controller',patched.indexOf('scramjet$token:t.scramjet$token'));
  const factories=[...patched.slice(0,marker).matchAll(/(\d+):function\(e,t,r\)\{/g)];
  const moduleId=Number(factories.at(-1)[1]);
  const context=vm.createContext({URL,TextEncoder,TextDecoder,Event,EventTarget,performance,atob,btoa,console});context.self=context;
  vm.runInContext(patched.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='),context);
  const listeners={},sent=[],nativeController={},serviceWorker={addEventListener:(type,listener)=>listeners[type]=listener};
  Object.defineProperty(serviceWorker,'controller',{get(){throw new Error('Page controller should not be used');}});
  const client={serviceWorker,cookieStore:{setCookies(){}},Trap(){},descriptors:{get:()=>nativeController},natives:{call:(name,controller,message)=>sent.push({name,controller,message})}};
  context.__testRequire(moduleId).default(client,{});
  listeners.message({data:{scramjet$type:'cookie',cookie:'session=current',url:site.href,scramjet$token:42}});
  assert.equal(sent.length,1);assert.equal(sent[0].controller,nativeController);assert.equal(sent[0].message.scramjet$token,42);
});
