import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';

const bundle=await readFile(new URL('../public/scram/scramjet.all.js',import.meta.url),'utf8');
const factory=bundle.match(/7758:function\(e,t,r\)\{([\s\S]*?)\},6012:function/);
assert.ok(factory,'Review the pinned popup hook when Scramjet changes.');
function opener(){
  const frame=new EventTarget(),opened=[],hooks={};
  frame.addEventListener('orbit-open-tab',event=>opened.push(event.url));
  const modules={3255:{ScramjetClient:class{constructor(){throw new Error('Native popup escaped Orbit');}}},2794:{pX:Symbol('client')},1472:{Oy:value=>'encoded:'+value}};
  const require=id=>modules[id];require.r=()=>{};require.d=(target,keys)=>{for(const [key,get]of Object.entries(keys))Object.defineProperty(target,key,{get});};
  const context=vm.createContext({URL,Event}),exports={};
  vm.runInContext('(function(e,t,r){'+factory[1]+'})',context)({},exports,require);
  exports.default({frame,url:new URL('https://game.example/play'),meta:{topFrameName:'orbit-frame',parentFrameName:'orbit-frame'},Proxy(name,hook){hooks[name]=hook;},Trap(){}});
  let nativeCalls=0;
  return {opened,open(address,target){let value;const args=[address,target];hooks['window.open'].apply({args,return(result){value=result;},call(){nativeCalls++;return null;}});return {value,nativeCalls,args};}};
}
test('addressed JavaScript popups open through Orbit without creating browser windows',()=>{
  const run=opener();
  assert.equal(run.open('/cloud/play','_blank').value,null);
  assert.equal(run.open('https://example.org/game','game-window').nativeCalls,0);
  assert.deepEqual(run.opened,['https://game.example/cloud/play','https://example.org/game']);
  assert.equal(run.open('/next','_self').nativeCalls,1);
  assert.equal(run.open('/next','_top').args[1],'orbit-frame');
});
test('empty, native-app, credential-bearing and script popups never escape or send secrets to the shell',()=>{
  const run=opener();
  for(const address of ['', 'roblox://experiences/start?ticket=secret', 'https://name:secret@example.org/', 'javascript:alert(1)'])assert.equal(run.open(address).nativeCalls,0);
  assert.deepEqual(run.opened,['','','','']);
});
test('new-window links and form submissions retain their destinations inside their Orbit frame',async()=>{
  const dom=new JSDOM('<a href="https://game.example/next" target="_blank"><span>Play</span></a><form target="_top"><button formtarget="_blank">Continue</button></form>',{url:'https://profiles.example/browse/game',runScripts:'outside-only'});
  try{
    dom.window.eval(await readFile(new URL('../public/orbit-navigation.js',import.meta.url),'utf8'));
    const link=dom.window.document.querySelector('a'),form=dom.window.document.querySelector('form'),button=form.querySelector('button');
    dom.window.document.addEventListener('click',event=>event.preventDefault());
    link.querySelector('span').dispatchEvent(new dom.window.MouseEvent('click',{bubbles:true,cancelable:true,composed:true}));
    assert.equal(link.target,'_self');assert.equal(link.href,'https://game.example/next');
    button.formTarget='_blank';form.dispatchEvent(new dom.window.SubmitEvent('submit',{bubbles:true,submitter:button}));
    assert.equal(form.target,'_self');assert.equal(button.formTarget,'_self');
  }finally{dom.window.close();}
});
