import test from 'node:test';
import assert from 'node:assert/strict';
import WebSocket,{WebSocketServer} from 'ws';
import {loadTransport} from '../scripts/transport-harness.mjs';

const remote=new URL('https://www.instagram.com/?hl=en');
function packet(type,id,payload){const header=Buffer.alloc(5);header[0]=type;header.writeUInt32LE(id,1);return Buffer.concat([header,payload]);}
async function relayFixture(t,{reason=0x42,dnsAnswer,lookupDelay=0,lateClose=false}={}){
  const server=new WebSocketServer({host:'127.0.0.1',port:0}),connections=[],clients=[];
  class FixtureSocket extends WebSocket {constructor(url,protocols){super(url,protocols);clients.push(this);}}
  await new Promise(resolve=>server.once('listening',resolve));
  server.on('connection',socket=>{
    const streams=new Map();
    socket.send(packet(3,0,Buffer.from([128,0,0,0])));
    socket.on('message',message=>{
      const bytes=Buffer.from(message),id=bytes.readUInt32LE(1);
      if(bytes[0]===1){
        const info={hostname:bytes.subarray(8).toString(),port:bytes.readUInt16LE(6),handshake:[],sequence:connections.length};
        streams.set(id,info);connections.push(info);
      }
      if(bytes[0]===2){
        const info=streams.get(id);info.handshake.push(bytes.subarray(5));
        if(!info.closed){info.closed=true;const finish=()=>socket.send(packet(4,id,Buffer.from([info.hostname==='www.instagram.com'?reason:3])));lateClose&&info.hostname==='www.instagram.com'?setTimeout(finish,info.sequence*100):finish();}
      }
    });
  });
  let lookups=0;
  const Transport=await loadTransport({WebSocket:FixtureSocket,fetch:async(url,options)=>{
    lookups++;assert.equal(url,'/api/dns?hostname=www.instagram.com');assert.equal(options.credentials,'include');
    if(lookupDelay)await new Promise(resolve=>setTimeout(resolve,lookupDelay));
    return Response.json(dnsAnswer||{hostname:'www.instagram.com',addresses:['8.8.8.8'],ttl:60});
  }});
  const client=new Transport({websocket:`ws://127.0.0.1:${server.address().port}/`});await client.init();
  t.after(async()=>{
    // These deliberately failed TLS handshakes can leave curl's poll timer
    // running. Dispose it along with the fixture's sockets and WASM session.
    client.session.close();for(const socket of clients)socket.terminate();for(const socket of server.clients)socket.terminate();
    await new Promise(resolve=>server.close(resolve));
    await new Promise(resolve=>setTimeout(resolve,10));Transport.disposeHarness();
  });
  return {client,connections,lookups:()=>lookups};
}
test('the real WASM client retries an unreachable hostname at its DNS address with the original TLS server name',async t=>{
  const fixture=await relayFixture(t);
  await assert.rejects(fixture.client.request(remote,'GET',undefined,{},AbortSignal.timeout(5000)),/code 35:/);
  assert.deepEqual(fixture.connections.map(c=>c.hostname),['www.instagram.com','8.8.8.8','8.8.8.8']);
  assert.equal(fixture.lookups(),1);
  for(const connection of fixture.connections){
    assert.equal(connection.port,443);
    assert.ok(Buffer.concat(connection.handshake).includes(Buffer.from('www.instagram.com')),'TLS SNI must remain the website hostname even when dialing an IP.');
  }
});
test('explicit relay policy blocks never trigger another DNS destination',async t=>{
  const fixture=await relayFixture(t,{reason:0x48});
  await assert.rejects(fixture.client.request(remote,'GET',undefined,{},AbortSignal.timeout(5000)),/code 35:/);
  assert.equal(fixture.lookups(),0);assert.deepEqual(fixture.connections.map(c=>c.hostname),Array(3).fill('www.instagram.com'));
});
test('a DNS answer with only a private destination is never dialed',async t=>{
  const fixture=await relayFixture(t,{dnsAnswer:{hostname:'www.instagram.com',addresses:['127.0.0.1'],ttl:60}});
  await assert.rejects(fixture.client.request(remote,'GET',undefined,{},AbortSignal.timeout(5000)),/code 35:/);
  assert.deepEqual(fixture.connections.map(c=>c.hostname),Array(3).fill('www.instagram.com'));
});
test('parallel failed connections share one DNS lookup',async t=>{
  const fixture=await relayFixture(t,{lookupDelay:50});
  const results=await Promise.allSettled(Array.from({length:3},()=>fixture.client.request(remote,'GET',undefined,{},AbortSignal.timeout(5000))));
  assert.ok(results.every(result=>result.status==='rejected'&&/code 35:/.test(result.reason.message)));
  assert.equal(fixture.lookups(),1);assert.equal(fixture.connections.filter(c=>c.hostname==='8.8.8.8').length,6);
});
test('late hostname failures reuse the DNS answer already obtained by another request',async t=>{
  const fixture=await relayFixture(t,{lateClose:true});
  const results=await Promise.allSettled(Array.from({length:3},()=>fixture.client.request(remote,'GET',undefined,{},AbortSignal.timeout(5000))));
  assert.ok(results.every(result=>result.status==='rejected'&&/code 35:/.test(result.reason.message)));
  assert.equal(fixture.lookups(),1);assert.equal(fixture.connections.filter(c=>c.hostname==='8.8.8.8').length,6);
});
