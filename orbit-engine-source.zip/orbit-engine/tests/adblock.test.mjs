import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

async function load(){
  const self={location:{origin:'https://orbit.example'},addEventListener(){}};let worker;
  class Worker extends EventTarget{constructor(){super();worker=this;this.config={prefix:'/browse/',orbitAdblock:{enabled:true,allowedSites:[]}};}}
  const context=vm.createContext({self,URL,Response,OrbitProfile:{configure(){}},fetch:async()=>Response.json({id:"test",key:"test"}),importScripts(){},$scramjetLoadWorker:()=>({ScramjetServiceWorker:Worker})});
  for(const file of ['adblock-hosts.js','adblock.js','sw.js'])vm.runInContext(await readFile(new URL('../public/'+file,import.meta.url),'utf8'),context);
  await vm.runInContext("ensureProfile()",context);
  return {worker,self};
}
function request(worker,url,{site='https://pokerogue.net/',destination='script'}={}){
  const event=new Event('request');Object.assign(event,{url:new URL(url),destination,client:{url:'https://orbit.example/browse/'+encodeURIComponent(site)}});worker.dispatchEvent(event);return event;
}

test('the bundled list blocks advertising hosts and subdomains before transport',async()=>{
  const {worker}=await load();
  const blocked=request(worker,'https://securepubads.g.doubleclick.net/tag.js');
  assert.equal(blocked.response.status,204);assert.equal(await blocked.response.text(),'');
  assert.equal(blocked.response.rawHeaders['access-control-allow-origin'],'*');
  assert.equal(blocked.response.body,null);
  assert.equal(request(worker,'https://doubleclick.net.example.org/app.js').response,undefined);
});

test('games, authentication, normal assets, explicit navigation and site exceptions pass through',async()=>{
  const {worker}=await load();
  for(const url of ['https://pokerogue.net/assets/battle-scene.js','https://pokerogue.net/images/pokemon/1.png','https://api.pokerogue.net/account/info','https://api.pokedoku.com/api/puzzle/solution/guess','https://fonts.gstatic.com/font.woff2'])assert.equal(request(worker,url).response,undefined);
  assert.equal(request(worker,'https://doubleclick.net/',{destination:'document'}).response,undefined);
  worker.config.orbitAdblock.allowedSites=['pokerogue.net'];
  assert.equal(request(worker,'https://doubleclick.net/tag.js').response,undefined);
  assert.equal(request(worker,'https://doubleclick.net/tag.js',{site:'https://sub.pokerogue.net/'}).response,undefined);
  assert.equal(request(worker,'https://doubleclick.net/tag.js',{site:'https://pokerogue.net.evil.example/'}).response.status,204);
  worker.config.orbitAdblock.enabled=false;
  assert.equal(request(worker,'https://doubleclick.net/tag.js',{site:'https://other.example/'}).response,undefined);
});
