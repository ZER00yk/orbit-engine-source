import test from 'node:test';
import assert from 'node:assert/strict';
import WebSocket from 'ws';
import worker from '../server/worker.mjs';
import {createRelay} from '../server/relay.mjs';

const origin='https://orbit.example';
const headers={'Upgrade':'websocket','Origin':origin,'oai-authenticated-user-id':'test-user'};
test('the Worker rejects unsigned and cross-origin relay requests',async()=>{
  assert.equal((await worker.fetch(new Request(origin+'/wisp/'),{})).status,401);
  assert.equal((await worker.fetch(new Request(origin+'/wisp/',{headers:{...headers,Origin:'https://other.example'}}),{})).status,403);
  assert.equal((await worker.fetch(new Request(origin+'/wisp/',{headers:{'oai-authenticated-user-id':'test-user'}}),{})).status,426);
});
test('the relay upstream and secret remain server-side',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);let sent;
  const fakeUpgrade={status:101};globalThis.fetch=async(url,options)=>{sent={url,options};return fakeUpgrade;};
  const result=await worker.fetch(new Request(origin+'/wisp/',{headers}),{WISP_UPSTREAM:'https://relay.example/wisp/',WISP_TOKEN:'private-secret'});
  assert.equal(result,fakeUpgrade);assert.equal(sent.url,'https://relay.example/wisp/');assert.equal(sent.options.headers.get('Authorization'),'Bearer private-secret');assert.equal(sent.options.headers.get('Origin'),origin);
  assert.equal(sent.options.headers.has('oai-authenticated-user-id'),false);
  const config=await worker.fetch(new Request(origin+'/api/config'),{WISP_UPSTREAM:'https://relay.example/wisp/',WISP_TOKEN:'private-secret'});assert.equal((await config.text()).includes('private-secret'),false);
});
test('a transient relay handshake recovers without changing servers or replaying game requests',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);const sent=[],fakeUpgrade={status:101};
  globalThis.fetch=async url=>{sent.push(url);return sent.length===1?new Response('Temporarily unavailable',{status:503}):fakeUpgrade;};
  assert.equal(await worker.fetch(new Request(origin+'/wisp/',{headers}),{}),fakeUpgrade);
  assert.equal(sent.length,2);assert.equal(sent[0],sent[1]);
});
test('relay retries are bounded and an upstream security rejection is not retried',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);
  for(const [status,expected]of [[503,2],[403,1],[429,1]]){
    let calls=0;globalThis.fetch=async()=>{calls++;return new Response('Unavailable',{status});};
    assert.equal((await worker.fetch(new Request(origin+'/wisp/',{headers}),{})).status,502);assert.equal(calls,expected);
  }
});
test('service worker assets receive the scope and isolation headers',async()=>{
  const response=await worker.fetch(new Request(origin+'/sw.js'),{ASSETS:{fetch:async()=>new Response('worker source')}});
  assert.equal(response.headers.get('Service-Worker-Allowed'),'/');assert.equal(response.headers.get('Cross-Origin-Embedder-Policy'),'require-corp');assert.equal(response.headers.get('Cache-Control'),'no-store');
});
test('the dedicated relay authenticates upgrades and rejects unauthorized clients',async t=>{
  const token='test-secret-'.repeat(4),server=createRelay({token,allowedOrigin:origin});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(()=>server.close());
  const address=`ws://127.0.0.1:${server.address().port}/wisp/`;
  const connect=options=>new Promise(resolve=>{
    const ws=new WebSocket(address,options);ws.on('message',message=>{const data=Buffer.from(message);ws.close();resolve({ok:data[0]===3});});ws.on('unexpected-response',(req,response)=>{response.resume();ws.terminate();resolve({status:response.statusCode});});ws.on('error',()=>{});
  });
  assert.deepEqual(await connect({headers:{Origin:origin}}),{status:403});
  assert.deepEqual(await connect({headers:{Origin:'https://wrong.example',Authorization:`Bearer ${token}`}}),{status:403});
  assert.deepEqual(await connect({headers:{Origin:origin,Authorization:`Bearer ${token}`}}),{ok:true});
});
