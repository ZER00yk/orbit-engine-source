import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {MessagePort,MessageChannel,BroadcastChannel} from 'node:worker_threads';
import {JSDOM} from 'jsdom';
import {rewriteDynamicImports} from '../src/module-imports.js';

const source=await readFile(new URL('../public/scram/scramjet.all.js',import.meta.url),'utf8');
const wasm=await readFile(new URL('../public/scram/scramjet.wasm.wasm',import.meta.url));
function rewriter(){
  const dom=new JSDOM('',{url:'https://profiles.example',runScripts:'outside-only'}),window=dom.window;
  Object.assign(window,{TextEncoder,TextDecoder,MessagePort,MessageChannel,BroadcastChannel});window.WASM=wasm.toString('base64');
  window.eval(source.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='));
  window.eval(`new ($scramjetLoadController().ScramjetController)({prefix:'/browse/',files:{wasm:'/scram/scramjet.wasm.wasm',all:'/scram/scramjet.all.js',sync:'/scram/scramjet.sync.js'},flags:{syncxhr:false,sourcemaps:false}});`);
  window.OrbitProfile={bootstrap:()=> 'globalThis.OrbitProfile.configure({id:"account-one",key:"private-key"});',rewriteJS:rewriteDynamicImports};
  function rewrite(code,address,worker=false){const meta={base:new window.URL(address),origin:new window.URL(address)},value=worker?window.__testRequire(2015).i(code,'module',address,meta):window.__testRequire(1478).o(code,address,meta,true);return typeof value==='string'?value:new TextDecoder().decode(value);}
  return {rewrite,close:()=>window.close()};
}

test('module-relative graphics workers and WASM assets resolve against the website address',async()=>{
  const compiler=rewriter();try{
    for(const address of ['https://vel.gg/bo1z/capabilities.js','https://game.example/nested/play.mjs?map=kino']){
      const workers=[],context=vm.createContext({URL,Worker:class{constructor(url,options){workers.push({url:url.href,options});}}});
      const code=compiler.rewrite('export async function launch(){new Worker(new URL("./capability-worker.js",import.meta.url),{type:"module"});return new URL("./engine.wasm",import.meta.url).href;}',address);
      const entry=new vm.SourceTextModule(code,{context,identifier:'https://profiles.example/browse/'+encodeURIComponent(address)+'?type=module',initializeImportMeta(meta,module){meta.url=module.identifier;}});
      await entry.link(()=>{throw new Error('Unexpected import');});await entry.evaluate();const asset=await entry.namespace.launch();
      assert.equal(workers[0].url,new URL('./capability-worker.js',address).href);assert.equal(workers[0].options.type,'module');assert.equal(asset,new URL('./engine.wasm',address).href);
    }
  }finally{compiler.close();}
});

test('module worker dependencies retain their own addresses and start after profile bootstrap',async()=>{
  const compiler=rewriter();try{
    const configured=[],calls=[],address='https://vel.gg/bo1z/capability-worker.js',dependency='https://vel.gg/bo1z/capabilities.js';
    const context=vm.createContext({URL,calls,OrbitProfile:{configure:p=>configured.push(p)},$scramjetLoadClient:()=>({loadAndHook(){assert.equal(configured.length,1);context.$scramjet$meta=(meta,url)=>Object.assign(meta,{url});calls.push('hooked');}})});
    const code=compiler.rewrite('import {resource} from "./capabilities.js";calls.push(resource);calls.push(new URL("./nested-worker.js",import.meta.url).href);',address,true);
    const entry=new vm.SourceTextModule(code,{context,identifier:'https://profiles.example/browse/'+encodeURIComponent(address)+'?dest=worker&type=module',initializeImportMeta(meta,module){meta.url=module.identifier;}});
    await entry.link(async specifier=>{
      if(specifier.startsWith('/browse/')){
        const target=new URL(specifier,'https://profiles.example');assert.equal(decodeURIComponent(target.pathname.slice('/browse/'.length)),dependency);
        return new vm.SourceTextModule(compiler.rewrite('export const resource=new URL("./renderer.wasm",import.meta.url).href;',dependency),{context,identifier:target.href,initializeImportMeta(meta,module){meta.url=module.identifier;}});
      }
      if(specifier.startsWith('data:application/javascript;base64,'))return new vm.SourceTextModule(Buffer.from(specifier.split(',')[1],'base64').toString('utf8'),{context});
      assert.ok(['/profile-runtime.js?v=4','/scram/scramjet.wasm.wasm','/scram/scramjet.all.js'].includes(specifier));return new vm.SyntheticModule([],function(){},{context});
    });await entry.evaluate();
    assert.deepEqual(calls,['hooked','https://vel.gg/bo1z/renderer.wasm','https://vel.gg/bo1z/nested-worker.js']);assert.equal(configured[0].id,'account-one');
  }finally{compiler.close();}
});
