import test from 'node:test';
import assert from 'node:assert/strict';
import {loadTransport} from '../scripts/transport-harness.mjs';

const Transport=await loadTransport();
const remote=new URL('https://api.pokedoku.com/api/puzzle/solution/guess');
const success={body:new TextEncoder().encode('{"result":true}'),status:200,statusText:'OK',raw_headers:[['content-type','application/json']]};
async function clientFor(t){const client=new Transport({websocket:'wss://relay.example/'});await client.init();t.after(()=>client.session.close());return client;}

test('a TLS handshake failure retries a streamed guess with identical bytes and request ID',async t=>{
  const client=await clientFor(t),sent=[];
  const json=JSON.stringify({puzzleId:123,cell:7,pokemonId:25,ranked:true});
  client.session.fetch=async(url,options)=>{
    const body=await new Response(options.body).text();sent.push({body,headers:options.headers,method:options.method});
    if(sent.length===1)throw new TypeError('Request failed with error code 35: SSL connect error');
    return success;
  };
  const stream=new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode(json));controller.close();}});
  const response=await client.request(remote,'POST',stream,{'content-type':'application/json','req-id':'one-guess','cookie':'session=fake'},undefined);
  assert.equal(response.status,200);assert.equal(sent.length,2);
  assert.equal(sent[0].body,json);assert.deepEqual(sent[0],sent[1]);
});

test('an uncertain save result, timeout, certificate failure or HTTP error is never replayed',async t=>{
  const client=await clientFor(t);
  for(const code of [28,52,55,56,60]){
    let calls=0;client.session.fetch=async()=>{calls++;throw new TypeError(`Request failed with error code ${code}: test failure`);};
    await assert.rejects(client.request(remote,'POST',new TextEncoder().encode('save data'),{},undefined),new RegExp(`code ${code}:`));
    assert.equal(calls,1);
  }
  for(const status of [400,401,409,429,500]){
    let calls=0;client.session.fetch=async()=>{calls++;return {...success,status};};
    assert.equal((await client.request(remote,'POST',undefined,{},undefined)).status,status);assert.equal(calls,1);
  }
});

test('connection retries are bounded and stop promptly when the request is cancelled',async t=>{
  const client=await clientFor(t);let calls=0;
  client.session.fetch=async()=>{calls++;throw new TypeError('Request failed with error code 7: Failed to connect');};
  await assert.rejects(client.request(remote,'POST',undefined,{},undefined),/code 7:/);assert.equal(calls,3);
  calls=0;const abort=new AbortController(),reason=new Error('Stopped by player');
  const request=client.request(remote,'POST',undefined,{},abort.signal);
  setTimeout(()=>abort.abort(reason),25);
  await assert.rejects(request,error=>error===reason);assert.equal(calls,1);
});
