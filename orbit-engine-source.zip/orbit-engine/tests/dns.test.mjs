import test from 'node:test';
import assert from 'node:assert/strict';
import {dnsResponse} from '../server/dns.mjs';
import {publicHostname,publicIPv4} from '../public/dns-policy.mjs';
import worker from '../server/worker.mjs';
import {patchLibcurlExports} from '../scripts/libcurl-patches.mjs';

const request=hostname=>new Request('https://orbit.example/api/dns?hostname='+encodeURIComponent(hostname),{
  headers:{Cookie:'private-orbit-session','X-Orbit-Ticket':'private-ticket','oai-authenticated-user-id':'test-user'},
});
test('DNS fallback accepts public names and rejects local, malformed and nonpublic addresses',()=>{
  for(const name of ['www.instagram.com','xn--bcher-kva.de'])assert.equal(publicHostname(name),true);
  for(const name of ['localhost','secret.local','internal.host.internal','hidden.onion','127.0.0.1','169.254.169.254','example.com/path','name..com','x'.repeat(64)+'.com'])assert.equal(publicHostname(name),false,name);
  for(const address of ['8.8.8.8','1.1.1.1','157.240.254.174'])assert.equal(publicIPv4(address),true);
  for(const address of ['0.0.0.0','10.0.0.1','100.64.0.1','127.0.0.1','169.254.169.254','172.16.0.1','192.168.0.1','192.0.2.1','198.18.0.1','198.51.100.1','203.0.113.1','224.0.0.1','255.255.255.255','8.8.8.256','008.8.8.8','::1'])assert.equal(publicIPv4(address),false,address);
});
test('DNS lookups require an authenticated engine and cannot turn into arbitrary URL fetches',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);let calls=0;
  globalThis.fetch=async()=>{calls++;throw new Error('Unexpected lookup');};
  assert.equal((await worker.fetch(new Request('https://orbit.example/api/dns?hostname=www.instagram.com'),{})).status,401);
  assert.equal((await worker.fetch(request('www.instagram.com'),{ORBIT_ENGINE_ORIGIN:'https://engine.example'})).status,404);
  assert.equal((await worker.fetch(new Request('https://orbit.example/api/dns?hostname=www.instagram.com'),{ORBIT_MODE:'engine'})).status,401);
  for(const name of ['https://example.com/','localhost','127.0.0.1'])assert.equal((await dnsResponse(request(name))).status,400);
  assert.equal((await dnsResponse(new Request(request('example.com'),{method:'POST'}))).status,405);
  assert.equal(calls,0);
});
test('the fixed HTTPS resolver receives only the hostname and honors the shortest CNAME lifetime',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);let sent;
  globalThis.fetch=async(url,options)=>{
    sent={url:new URL(url),options};return Response.json({Status:0,Answer:[
      {type:5,TTL:25,data:'destination.example.'},{type:1,TTL:60,data:'8.8.8.8'},
      {type:1,TTL:60,data:'8.8.8.8'},{type:1,TTL:60,data:'127.0.0.1'},
    ]});
  };
  const response=await worker.fetch(request('www.instagram.com'),{});
  assert.equal(response.status,200);assert.equal(response.headers.get('Cache-Control'),'no-store');
  assert.deepEqual(await response.json(),{hostname:'www.instagram.com',addresses:['8.8.8.8'],ttl:25});
  assert.equal(sent.url.origin,'https://dns.google');assert.equal(sent.url.pathname,'/resolve');
  assert.equal(sent.url.searchParams.get('name'),'www.instagram.com');assert.equal(sent.url.searchParams.get('type'),'A');
  assert.equal(sent.url.searchParams.get('edns_client_subnet'),'0.0.0.0/0');
  assert.deepEqual(sent.options.headers,{Accept:'application/json'});assert.equal(sent.options.redirect,'manual');
});
test('invalid, private-only, expired and failed DNS answers leave the original connection failure intact',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);
  for(const data of [
    {Status:2,Answer:[{type:1,TTL:60,data:'8.8.8.8'}]},
    {Status:0,TC:true,Answer:[{type:1,TTL:60,data:'8.8.8.8'}]},
    {Status:0,Answer:[{type:1,TTL:60,data:'10.0.0.1'}]},
    {Status:0,Answer:[{type:1,TTL:0,data:'8.8.8.8'}]},
    {Status:0,Answer:[{type:5,TTL:0,data:'alias.example.'},{type:1,TTL:60,data:'8.8.8.8'}]},
  ]){
    globalThis.fetch=async()=>Response.json(data);
    assert.equal((await dnsResponse(request('www.instagram.com'))).status,502);
  }
  globalThis.fetch=async()=>{throw new Error('Resolver unavailable');};
  assert.equal((await dnsResponse(request('www.instagram.com'))).status,502);
});
test('the engine verifies the active private profile before any DNS lookup and rejects revoked tickets',async t=>{
  const original=globalThis.fetch;t.after(()=>globalThis.fetch=original);
  const env={ORBIT_MODE:'engine',ORBIT_APP_ORIGIN:'https://account.example'},ticket='ticket.'+'s'.repeat(43);
  const engineRequest=new Request('https://engine.example/api/dns?hostname=www.instagram.com',{
    headers:{Cookie:'__Host-orbit-engine='+ticket},
  });
  const calls=[];let revoked=false;
  globalThis.fetch=async(url,options)=>{
    calls.push({url,options});
    if(url==='https://account.example/api/engine-authorize'){
      assert.equal(options.headers['X-Orbit-Ticket'],ticket);
      return revoked?new Response('Revoked',{status:401}):Response.json({id:'i'.repeat(43),key:'k'.repeat(43)});
    }
    assert.equal(new URL(url).origin,'https://dns.google');assert.deepEqual(options.headers,{Accept:'application/json'});
    return Response.json({Status:0,Answer:[{type:1,TTL:60,data:'8.8.8.8'}]});
  };
  assert.equal((await worker.fetch(engineRequest,env)).status,200);assert.equal(calls.length,2);
  revoked=true;calls.length=0;
  assert.equal((await worker.fetch(engineRequest,env)).status,401);assert.equal(calls.length,1);
});
test('an upstream libcurl export change stops vendoring rather than silently disabling the adapter',()=>{
  assert.throws(()=>patchLibcurlExports('changed source'),/Pinned libcurl exports changed/);
});
