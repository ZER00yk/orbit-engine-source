import test from 'node:test';
import assert from 'node:assert/strict';
import {token} from '../server/account-crypto.mjs';
import {disk,realm,allFiles} from '../scripts/opfs-harness.mjs';
const account=()=>({id:token(),key:token()}),encoder=new TextEncoder();
const equal=(actual,expected)=>assert.equal(Buffer.compare(Buffer.from(actual),Buffer.from(expected)),0);
async function file(root,name='cache.json'){return root.getFileHandle(name,{create:true});}

test('opaque helper documents install proxy hooks without stopping game startup or opening unscoped storage',async()=>{
  for(const url of ['about:blank','about:srcdoc','data:text/html,']){
    const shared=disk(),r=realm(shared,account(),url);
    await assert.rejects(()=>r.directory(),{name:'SecurityError'});
    assert.equal(shared.root.children.size,0);
  }
});

test('blank helper frames and blob workers use the creator website encrypted file scope',async()=>{
  const shared=disk(),p=account(),site='https://pokerogue.net',r=realm(shared,p,site),h=await file(await r.directory());
  const write=await h.createWritable();await write.write('private-game-cache');await write.close();
  for(const url of ['about:blank','about:srcdoc','blob:https://pokerogue.net/graphics-worker']){
    const child=realm(shared,p,url,site),root=await child.directory();
    assert.equal(await (await (await root.getFileHandle('cache.json')).getFile()).text(),'private-game-cache');
  }
  const other=realm(shared,p,'about:blank','https://other.example');
  await assert.rejects(async()=>{await (await other.directory()).getFileHandle('cache.json');},{name:'NotFoundError'});
  assert.equal(allFiles(shared.root).some(node=>Buffer.from(node.data).includes(Buffer.from('private-game-cache'))),false);
});

test('the real Scramjet OPFS hook encrypts files and isolates users and websites',async()=>{
  const shared=disk(),alice=account(),a=realm(shared,alice),root=await a.directory(),handle=await file(root),access=await handle.createSyncAccessHandle();
  assert.equal(root.name,'');access.write(encoder.encode('private-login-cookie'));access.flush();access.close();
  assert.equal(await (await handle.getFile()).text(),'private-login-cookie');
  assert.equal(allFiles(shared.root).some(node=>Buffer.from(node.data).includes(Buffer.from('private-login-cookie'))),false);
  assert.deepEqual(Array.from(await Array.fromAsync(root.keys())),['cache.json']);
  const b=realm(shared,account()),other=await b.directory();await assert.rejects(()=>other.getFileHandle('cache.json'),{name:'NotFoundError'});
  const site=realm(shared,alice,'https://other.example'),siteRoot=await site.directory();await assert.rejects(()=>siteRoot.getFileHandle('cache.json'),{name:'NotFoundError'});
  const native=allFiles(shared.root)[0];await assert.rejects(()=>b.unscoped(native).getFile(),{name:'SecurityError'});
  await assert.rejects(()=>root.getDirectoryHandle('../'),TypeError);
});

test('synchronous random file reads preserve offsets, holes, sizes and chunk boundaries',async()=>{
  const shared=disk(),p=account(),r=realm(shared,p),root=await r.directory(),h=await file(root,'pack.iwd'),a=await h.createSyncAccessHandle();
  const input=new Uint8Array(150001);for(let i=0;i<input.length;i++)input[i]=i%251;assert.equal(a.write(input,{at:65530}),input.length);
  r.profile.configure(p);assert.equal(a.getSize(),65530+input.length);const out=new Uint8Array(a.getSize());assert.equal(a.read(out,{at:0}),out.length);equal(out.subarray(65530),input);assert.equal(out.subarray(0,65530).every(x=>x===0),true);
  a.write(encoder.encode('end'),{at:700000});assert.equal(a.getSize(),700003);const gap=new Uint8Array(10);a.read(gap,{at:690000});assert.equal(gap.every(x=>x===0),true);
  assert.equal(a.write(new Uint8Array(),{at:800000}),0);assert.equal(a.getSize(),700003);assert.throws(()=>a.read(gap,{at:-1}),{name:'TypeError'});a.close();
  const worker=realm(shared,p),reopened=await (await worker.directory()).getFileHandle('pack.iwd'),b=await reopened.createSyncAccessHandle();assert.equal(b.getSize(),700003);const final=new Uint8Array(3);b.read(final,{at:700000});equal(final,encoder.encode('end'));b.close();
});

test('truncating and extending a file never resurrects the removed plaintext tail',async()=>{
  const r=realm(disk(),account()),h=await file(await r.directory()),a=await h.createSyncAccessHandle();a.write(new Uint8Array(150000).fill(123));a.truncate(64001);a.truncate(150000);assert.equal(a.getSize(),150000);const out=new Uint8Array(150000);a.read(out,{at:0});assert.equal(out.subarray(0,64001).every(x=>x===123),true);assert.equal(out.subarray(64001).every(x=>x===0),true);a.truncate(0);a.truncate(70000);const blank=new Uint8Array(70000);a.read(blank,{at:0});assert.equal(blank.every(x=>x===0),true);a.close();
});

test('file snapshots read decrypted slices and streams while exposing the logical file size',async()=>{
  const shared=disk(),p=account(),r=realm(shared,p),h=await file(await r.directory(),'pack.iwd'),a=await h.createSyncAccessHandle(),input=new Uint8Array(200000);for(let i=0;i<input.length;i++)input[i]=i%251;a.write(input);a.close();
  const blob=await h.getFile();assert.equal(blob.size,input.length);assert.equal(blob.name,'pack.iwd');assert.equal(blob instanceof File,true);equal(new Uint8Array(await blob.slice(65530,65545).arrayBuffer()),input.subarray(65530,65545));equal(new Uint8Array(await blob.slice(-9).arrayBuffer()),input.subarray(input.length-9));equal(new Uint8Array(await new Response(blob.stream()).arrayBuffer()),input);
  const a2=await h.createSyncAccessHandle({mode:'read-only'});assert.throws(()=>a2.write(new Uint8Array([1])),{name:'NoModificationAllowedError'});a2.close();
});

test('authenticated file headers and blocks reject tampering and another account key',async()=>{
  const shared=disk(),r=realm(shared,account()),h=await file(await r.directory()),a=await h.createSyncAccessHandle();a.write(encoder.encode('secret'));a.close();const node=allFiles(shared.root)[0],original=node.data.slice();
  node.data[150]^=1;await assert.rejects(async()=>{await (await h.getFile()).text();},{name:'NotReadableError'});node.data=original.slice();node.data.fill(0,128);await assert.rejects(async()=>{await (await h.getFile()).text();},{name:'NotReadableError'});node.data=original.slice();node.data[40]^=1;await assert.rejects(()=>h.getFile(),{name:'NotReadableError'});node.data=original;
  const other=realm(shared,account()),otherHandle=await file(await other.directory());otherHandle.node.data=original.slice();await assert.rejects(()=>otherHandle.getFile(),{name:'NotReadableError'});
});

test('asynchronous writable files commit and abort atomically with encrypted data',async()=>{
  const shared=disk(),r=realm(shared,account()),root=await r.directory(),h=await file(root),a=await h.createSyncAccessHandle();a.write(encoder.encode('original'));a.close();
  const abort=await h.createWritable();await abort.write('discarded');assert.equal(await (await h.getFile()).text(),'original');await abort.abort();assert.equal(await (await h.getFile()).text(),'original');
  const w=await h.createWritable({keepExistingData:true});await w.seek(4);await w.write('UPDATED');await w.truncate(12);await w.close();assert.equal((await h.getFile()).size,12);equal(new Uint8Array(await (await h.getFile()).arrayBuffer()),encoder.encode('origUPDATED\0'));await assert.rejects(()=>w.write('closed'));
  assert.equal(allFiles(shared.root).some(node=>Buffer.from(node.data).includes(Buffer.from('UPDATED'))),false);assert.deepEqual(Array.from(await Array.fromAsync(root.keys())),['cache.json']);
});

test('standard WritableStream piping uses the same encrypted file writer',async()=>{
  const r=realm(disk(),account()),h=await file(await r.directory()),w=await h.createWritable();await new ReadableStream({start(c){c.enqueue(encoder.encode('first'));c.enqueue(encoder.encode('second'));c.close();}}).pipeTo(w);assert.equal(await (await h.getFile()).text(),'firstsecond');
});

test('small game-pack slices reuse the encrypted snapshot block without sharing mutable bytes or bypassing sign-out',async()=>{
  const shared=disk(),p=account(),r=realm(shared,p),root=await r.directory(),h=await file(root,'boot-pack.iwd'),input=new Uint8Array(131072);
  for(let i=0;i<input.length;i++)input[i]=i%251;
  const writer=await h.createWritable();await writer.write(input);await writer.close();const snapshot=await h.getFile(),before=shared.snapshotReads;
  for(let at=0;at<65536;at+=8192)equal(new Uint8Array(await snapshot.slice(at,at+8192).arrayBuffer()),input.subarray(at,at+8192));
  assert.equal(shared.snapshotReads-before,1,'Eight small reads should need only one encrypted block read');
  const changed=new Uint8Array(await snapshot.slice(0,8192).arrayBuffer());changed.fill(0);
  equal(new Uint8Array(await snapshot.slice(0,8192).arrayBuffer()),input.subarray(0,8192));
  equal(new Uint8Array(await snapshot.slice(65530,65550).arrayBuffer()),input.subarray(65530,65550));
  const other=realm(shared,account()),otherRoot=await other.directory();await assert.rejects(()=>otherRoot.getFileHandle('boot-pack.iwd'),{name:'NotFoundError'});
  r.profile.clearMemory();await assert.rejects(()=>snapshot.slice(0,8192).arrayBuffer());
  assert.equal(allFiles(shared.root).some(node=>Buffer.from(node.data).includes(Buffer.from(input.subarray(0,4096)))),false);
});

test('asynchronous file writes cross block boundaries and safely extend a truncated tail',async()=>{
  const r=realm(disk(),account()),h=await file(await r.directory()),w=await h.createWritable(),input=new Uint8Array(140000);for(let i=0;i<input.length;i++)input[i]=i%251;await w.write(input);await w.truncate(65530);await w.truncate(200000);await w.seek(199997);await w.write('end');await w.close();const result=await h.getFile();assert.equal(result.size,200000);equal(new Uint8Array(await result.slice(0,65530).arrayBuffer()),input.subarray(0,65530));const removed=new Uint8Array(await result.slice(65530,199997).arrayBuffer());assert.equal(removed.every(x=>x===0),true);assert.equal(await result.slice(-3).text(),'end');
});

test('signing out revokes existing file handles and snapshots and releases writer locks',async()=>{
  const r=realm(disk(),account()),root=await r.directory(),h=await file(root),a=await h.createSyncAccessHandle();a.write(encoder.encode('private'));const snapshot=await h.getFile();r.profile.clearMemory();assert.throws(()=>a.read(new Uint8Array(10)));await assert.rejects(()=>h.getFile());await assert.rejects(()=>snapshot.text());assert.equal(h.node.active.size,0);a.close();
});

test('download locks are private to each account and virtual website',async()=>{
  const shared=disk(),a=realm(shared,account()),b=realm(shared,account());let release;const wait=new Promise(resolve=>release=resolve);const first=a.context.navigator.locks.request('pack-download',async lock=>{assert.equal(lock.name,'pack-download');await wait;});await new Promise(resolve=>setTimeout(resolve,0));const own=await a.context.navigator.locks.query(),other=await b.context.navigator.locks.query();assert.equal(own.held[0].name,'pack-download');assert.equal(other.held.length,0);let secondEntered=false;await b.context.navigator.locks.request('pack-download',()=>{secondEntered=true;});assert.equal(secondEntered,true);release();await first;
});
