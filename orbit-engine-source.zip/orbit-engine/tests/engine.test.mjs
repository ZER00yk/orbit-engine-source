import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {loadTransport} from '../scripts/transport-harness.mjs';
import {prepareServiceWorker} from '../src/service-worker.js';

test('parallel requests share real libcurl WASM startup and all become ready',async()=>{
  const Transport=await loadTransport({instantiateDelay:35});
  const client=new Transport({websocket:'wss://relay.example/'});
  assert.equal(client.ready,false);
  const starts=Array.from({length:12},()=>client.init());
  assert.ok(starts.every(promise=>promise===starts[0]));
  let timer;
  await Promise.race([Promise.all(starts),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Parallel initialization stalled.')),2000);})]).finally(()=>clearTimeout(timer));
  assert.equal(client.ready,true);
  assert.ok(client.session);
  let sent;
  client.session.fetch=async(url,options)=>{
    sent={url,options};
    return {body:new Uint8Array([1,2]),status:200,statusText:'OK',raw_headers:[['Content-Type','text/plain'],['Set-Cookie','first=1'],['Set-Cookie','second=2']]};
  };
  const response=await client.request(new URL('https://game.example/'),'GET',undefined,{'Accept':'*/*','Origin':'https://game.example'},undefined);
  assert.equal(sent.options.headers.Origin,'https://game.example');
  assert.equal(sent.options.headers.Accept,'*/*');
  assert.deepEqual(Array.from(response.headers['set-cookie']),['first=1','second=2']);
  assert.equal(response.headers['content-type'][0],'text/plain');
});

test('the shipped libcurl WASM transport starts and fetches without SharedArrayBuffer or browser isolation',async()=>{
  const Transport=await loadTransport({sharedMemory:false}),client=new Transport({websocket:'wss://relay.example/'});
  await client.init();assert.equal(client.ready,true);assert.ok(client.session);
  client.session.fetch=async()=>({body:new Uint8Array([1]),status:200,statusText:'OK',raw_headers:[['Content-Type','text/plain']]});
  const response=await client.request(new URL('https://game.example/'),'GET',undefined,{},undefined);
  assert.equal(response.status,200);assert.deepEqual(Array.from(response.body),[1]);
});

test('a ready service worker must claim the page before frames can open',async()=>{
  const workers=new EventTarget(),registration={active:{}};
  workers.controller=null;workers.register=async()=>registration;workers.ready=Promise.resolve(registration);
  let finished=false;const start=prepareServiceWorker(workers,200).then(()=>finished=true);
  await new Promise(resolve=>setTimeout(resolve,10));assert.equal(finished,false);
  workers.controller=registration.active;workers.dispatchEvent(new Event('controllerchange'));
  await start;assert.equal(finished,true);
});

test('a worker that never claims the page reports an error instead of hanging',async()=>{
  const workers=new EventTarget(),registration={active:{}};
  workers.controller=null;workers.register=async()=>registration;workers.ready=Promise.resolve(registration);
  await assert.rejects(prepareServiceWorker(workers,20),/couldn’t take control/);
});
test('switching profiles waits for the replacement worker instead of reusing the previous cookie jar',async()=>{
  const workers=new EventTarget(),previous={scriptURL:'https://profiles.example/sw.js?v=2&profile=previous'},next={scriptURL:'https://profiles.example/sw.js?v=2&profile=next'},registration={active:previous};
  workers.controller=previous;workers.register=async()=>registration;workers.ready=Promise.resolve(registration);
  let finished=false;const start=prepareServiceWorker(workers,200,'/sw.js?v=2&profile=next').then(()=>finished=true);
  await new Promise(resolve=>setTimeout(resolve,10));assert.equal(finished,false);
  registration.active=next;workers.controller=next;workers.dispatchEvent(new Event('controllerchange'));await start;assert.equal(finished,true);
});

test('Orbit assets bypass proxy configuration while game requests are routed',async()=>{
  const listeners={},routed=[];let worker;
  const notices=[];
  const self={location:{origin:'https://orbit.example'},clients:{matchAll:async()=>[{url:'https://orbit.example/',postMessage:message=>notices.push(message)}]},addEventListener:(name,fn)=>listeners[name]=fn};
  class Worker extends EventTarget{
    constructor(){super();worker=this;}
    async loadConfig(){routed.push('config');}
    route(){return true;}
    async fetch(event){routed.push(event.request.url);return new Response('game');}
  }
  const context=vm.createContext({OrbitProfile:{configure(){}},fetch:async()=>Response.json({id:"test",key:"test"}),self,URL,Response,importScripts(){},$scramjetLoadWorker:()=>({ScramjetServiceWorker:Worker})});
  vm.runInContext(await readFile(new URL('../public/site-status.js',import.meta.url),'utf8'),context);
  vm.runInContext(await readFile(new URL('../public/app-links.js',import.meta.url),'utf8'),context);
  vm.runInContext(await readFile(new URL('../public/sw.js',import.meta.url),'utf8'),context);
  let intercepted=false;
  listeners.fetch({request:new Request('https://orbit.example/assets/app.js'),respondWith(){intercepted=true;}});
  assert.equal(intercepted,false);assert.equal(routed.length,0);
  let response;
  listeners.fetch({request:new Request('https://orbit.example/browse/https%3A%2F%2Fgame.example%2F'),respondWith(value){response=value;}});
  assert.equal(await (await response).text(),'game');assert.equal(routed.length,2);
  const inject=new Event('handleResponse');
  Object.assign(inject,{destination:'iframe',url:new URL('https://pokerogue.net/'),responseHeaders:{'content-type':'text/html'},responseBody:'<!doctype html><html><head><script src="/scram/scramjet.all.js"></script></head><body></body></html>'});
  worker.dispatchEvent(inject);
  assert.ok(inject.responseBody.indexOf('/game-diagnostics.js')<inject.responseBody.indexOf('/scram/scramjet.all.js'));
  const other=new Event('handleResponse');
  Object.assign(other,{...inject,url:new URL('https://example.org/'),responseBody:'<head>unchanged</head>'});worker.dispatchEvent(other);
  assert.equal(other.responseBody,'<head><script src="/orbit-navigation.js?v=1"></script>unchanged</head>');
  assert.equal(other.responseHeaders['Cross-Origin-Embedder-Policy'],'require-corp');
  const vel=new Event('handleResponse');
  Object.assign(vel,{destination:'iframe',status:200,url:new URL('https://vel.gg/bo1z/kino'),responseHeaders:{'content-type':'text/html'},responseBody:'<head><script type="module" src="play.js"></script></head>'});
  worker.dispatchEvent(vel);
  const bootScript=vel.responseBody.match(/<script>([^<]+)<\/script>/)[1],gameContext=vm.createContext({});
  vm.runInContext(bootScript,gameContext);
  assert.equal(gameContext.__kisakNoOverlap,true,'Use vel.gg’s supported boot-ready fallback before engine mounting.');
  assert.ok(vel.responseBody.indexOf(bootScript)<vel.responseBody.indexOf('src="play.js"'));
  assert.equal(other.responseBody.includes('__kisakNoOverlap'),false);
  const challenge=new Event('handleResponse');
  Object.assign(challenge,{destination:'iframe',url:new URL('https://neal.fun/password-game/'),status:403,responseHeaders:{'content-type':'text/html','cf-mitigated':'challenge'},responseBody:'<head>Cloudflare check</head>'});
  worker.dispatchEvent(challenge);await Promise.resolve();
  assert.equal(notices.length,1);assert.equal(notices[0].site,'neal.fun');
  assert.equal(challenge.status,403);assert.equal(challenge.responseBody,'<head>Cloudflare check</head>');
  const velChallenge=new Event('handleResponse');
  Object.assign(velChallenge,{...challenge,url:new URL('https://vel.gg/bo1z/kino'),responseHeaders:{'content-type':'text/html','cf-mitigated':'challenge'},responseBody:'<head>Cloudflare check</head>'});
  worker.dispatchEvent(velChallenge);assert.equal(velChallenge.responseBody,'<head>Cloudflare check</head>');
  const appRequest=new Request('https://orbit.example/browse/'+encodeURIComponent('roblox://experiences/start?placeId=123'));
  Object.defineProperty(appRequest,'destination',{value:'iframe'});
  const before=routed.length;
  listeners.fetch({request:appRequest,respondWith(value){response=value;}});
  assert.match(await (await response).text(),/Return to Roblox in Orbit/);assert.equal(routed.length,before,'Native links must bypass both the rewriter and HTTP transport.');
});
