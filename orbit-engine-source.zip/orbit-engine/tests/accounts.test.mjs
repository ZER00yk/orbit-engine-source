import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs/promises';
import {accountRoutes} from '../server/accounts.mjs';
import {token,hash,profileKey,verifyTicket} from '../server/account-crypto.mjs';
import {engineRoutes,engineContext} from '../server/engine-auth.mjs';
const origin='https://orbit.example',engine='https://profiles.example',password='a long personal passphrase 123';
function database(){
  const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
  return {sql,prepare(query){const statement=sql.prepare(query);let args=[];return {bind(...values){args=values;return this;},async first(){return statement.get(...args)||null;},async run(){return statement.run(...args);}};},async batch(statements){sql.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(await statement.run());sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
}
async function fixture(){const DB=database();DB.sql.exec(await fs.readFile(new URL('../drizzle/0000_silent_vapor.sql',import.meta.url),'utf8'));const setup=token();const env={DB,ORBIT_ENGINE_ORIGIN:engine,ORBIT_TICKET_SECRET:token(),ORBIT_PROFILE_SECRET:token(),ORBIT_SETUP_HASH:hash(setup)};
  const call=(path,{method='GET',data,cookie='',from=origin,ip='test'}={})=>accountRoutes(new Request(origin+'/api/'+path,{method,headers:{Origin:from,Cookie:cookie,'CF-Connecting-IP':ip,...data&&{'Content-Type':'application/json'}},body:data&&JSON.stringify(data)}),env);
  const create=async(username,code,path='register')=>call(path,{method:'POST',data:{username,password,code}});
  const ownerResponse=await create('owner',setup,'setup');assert.equal(ownerResponse.status,200);const owner=await ownerResponse.json();const ownerCookie=ownerResponse.headers.get('Set-Cookie').split(';')[0];
  const invite=await (await call('invites',{method:'POST',cookie:ownerCookie,data:{}})).json();
  return {DB,env,setup,call,create,ownerCookie,owner,code:new URL(invite.url).hash.slice(8)};
}
test('owner setup requires a secret and cannot be repeated or won by an anonymous first visitor',async()=>{
  const f=await fixture();assert.equal((await f.create('attacker',token(),'setup')).status,403);assert.equal((await f.create('second-owner',f.setup,'setup')).status,403);assert.equal((await f.create('uninvited',token())).status,403);
  assert.equal(f.DB.sql.prepare("SELECT count(*) AS n FROM users WHERE role='owner'").get().n,1);f.DB.sql.close();
});
test('a one-use invitation creates a member whose profile and sessions cannot access the owner',async()=>{
  const f=await fixture(),response=await f.create('friend',f.code);assert.equal(response.status,200);const member=await response.json(),cookie=response.headers.get('Set-Cookie').split(';')[0];
  assert.equal(member.user.role,'member');assert.equal((await f.create('reuse',f.code)).status,403);assert.equal((await f.call('invites',{method:'POST',cookie,data:{}})).status,403);
  const ownerCipher='v1.'+Buffer.from('encrypted-owner-profile').toString('base64url');await f.call('profile',{method:'PUT',cookie:f.ownerCookie,data:{cipher:ownerCipher,userId:f.owner.user.id}});
  assert.equal((await(await f.call('profile',{cookie})).json()).cipher,null);
  const friendCipher='v1.'+Buffer.from('encrypted-friend-profile').toString('base64url');assert.equal((await f.call('profile',{method:'PUT',cookie,data:{cipher:friendCipher,userId:f.owner.user.id}})).status,409);await f.call('profile',{method:'PUT',cookie,data:{cipher:friendCipher,userId:member.user.id}});
  assert.equal((await(await f.call('profile',{cookie:f.ownerCookie})).json()).cipher,ownerCipher);
  const a=await(await f.call('account',{cookie:f.ownerCookie})).json(),b=await(await f.call('account',{cookie})).json();assert.notEqual(a.key,b.key);assert.equal(b.key,profileKey(member.user.id,f.env.ORBIT_PROFILE_SECRET));
  assert.equal((await f.call('profile')).status,401);f.DB.sql.close();
});
test('passwords and session tokens are stored as salted hashes; CSRF and forged cookies fail',async()=>{
  const f=await fixture(),row=f.DB.sql.prepare('SELECT password FROM users').get();assert.match(row.password,/^scrypt:16384:8:5:/);assert.equal(row.password.includes(password),false);
  const raw=f.ownerCookie.split('=')[1],session=f.DB.sql.prepare('SELECT hash FROM sessions').get();assert.equal(session.hash,hash(raw));assert.equal(session.hash.includes(raw),false);
  assert.equal((await f.call('logout',{method:'POST',cookie:f.ownerCookie,data:{},from:engine})).status,403);
  assert.equal((await f.call('profile',{cookie:'__Host-orbit-session='+token()})).status,401);
  assert.equal((await f.call('login',{method:'POST',data:{username:'owner',password:'incorrect long password'}})).status,401);
  const login=await f.call('login',{method:'POST',data:{username:'owner',password}});assert.equal(login.status,200);assert.match(login.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=Strict/);f.DB.sql.close();
});
test('engine tickets bind the account, origin and active session; logout invalidates them',async()=>{
  const f=await fixture(),{ticket}=await(await f.call('engine-ticket',{method:'POST',cookie:f.ownerCookie,data:{}})).json();
  assert.ok(verifyTicket(ticket,f.env.ORBIT_TICKET_SECRET,{issuer:origin,audience:engine}));assert.equal(verifyTicket(ticket,f.env.ORBIT_TICKET_SECRET,{issuer:origin,audience:origin}),null);assert.equal(verifyTicket(ticket+'x',f.env.ORBIT_TICKET_SECRET,{issuer:origin,audience:engine}),null);
  const request=()=>f.call('engine-authorize',{method:'POST'});
  const authorize=()=>accountRoutes(new Request(origin+'/api/engine-authorize',{method:'POST',headers:{Authorization:'Bearer '+ticket}}),f.env);
  assert.equal((await authorize()).status,200);await f.call('logout',{method:'POST',cookie:f.ownerCookie,data:{}});assert.equal((await authorize()).status,401);assert.equal((await f.call('profile',{cookie:f.ownerCookie})).status,401);f.DB.sql.close();
});
test('expired invitations and sessions are rejected and repeated password guesses are throttled',async()=>{
  const f=await fixture();f.DB.sql.prepare('UPDATE invites SET expires=0').run();assert.equal((await f.create('expired',f.code)).status,403);
  f.DB.sql.prepare('UPDATE sessions SET expires=0').run();assert.equal((await f.call('account',{cookie:f.ownerCookie})).status,401);
  let response;for(let i=0;i<16;i++)response=await f.call('login',{method:'POST',data:{username:'missing',password:'a wrong but long password'},ip:'abuse'});assert.equal(response.status,429);f.DB.sql.close();
});

test('the engine uses the account server to validate tickets and rejects anonymous, forged and revoked sessions',async()=>{
  const f=await fixture(),{ticket}=await(await f.call('engine-ticket',{method:'POST',cookie:f.ownerCookie,data:{}})).json();const env={ORBIT_APP_ORIGIN:origin};const original=globalThis.fetch;globalThis.fetch=async(url,init)=>{const headers=new Headers(init.headers);headers.delete('Authorization');return accountRoutes(new Request(url,{...init,headers}),f.env);};
  try{
    const boot=async(from,value)=>engineRoutes(new Request(engine+'/api/bootstrap',{method:'POST',headers:{Origin:from,Authorization:'Bearer '+value}}),env);
    assert.equal((await boot(origin,ticket)).status,403);assert.equal((await boot(engine,'bad')).status,401);const [payload]=ticket.split('.');assert.equal((await boot(engine,payload+'.'+token())).status,401);const response=await boot(engine,ticket);assert.equal(response.status,200);assert.match(response.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=None; Partitioned/);const context=await response.json();assert.equal(context.id,f.owner.user.id);
    assert.equal((await engineRoutes(new Request(engine+'/api/bootstrap',{method:'POST',headers:{Origin:engine,'X-Orbit-Ticket':ticket}}),env)).status,200);
    const request=new Request(engine+'/wisp/',{headers:{Cookie:response.headers.get('Set-Cookie').split(';')[0]}});assert.equal((await engineContext(request,env)).id,f.owner.user.id);
    await f.call('logout',{method:'POST',cookie:f.ownerCookie,data:{}});assert.equal(await engineContext(request,env),null);
  }finally{globalThis.fetch=original;f.DB.sql.close();}
});
