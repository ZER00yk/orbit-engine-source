import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {JSDOM} from 'jsdom';
test('the account page accepts bridge events only from the exact engine origin, frame and channel',async()=>{
  const dom=new JSDOM('<div id="frames"></div>',{url:'https://app.example',runScripts:'outside-only',pretendToBeVisual:true}),w=dom.window;let calls=0;w.currentAccount=()=>({id:'owner',engine:'https://engine.example'});w.api=async()=>{calls++;return {ticket:'signed-ticket'};};w.migrateOwner=()=>Promise.resolve();
  const source=(await fs.readFile(new URL('../src/remote-engine.js',import.meta.url),'utf8')).replace(/^import .+;\s*$/gm,'').replace('export class RemoteController','window.RemoteController = class RemoteController');w.eval(source);const controller=new w.RemoteController(),frame=controller.createFrame();w.document.body.append(frame.frame);const messages=[];frame.frame.contentWindow.postMessage=(data,origin)=>messages.push({data,origin});
  assert.equal(frame.frame.getAttribute('allow'),'cross-origin-isolated');
  const send=(origin,source,channel=frame.channel,type='ready')=>w.dispatchEvent(new w.MessageEvent('message',{origin,source,data:{channel,type}}));
  send('https://attacker.example',frame.frame.contentWindow);send('https://engine.example',w);send('https://engine.example',frame.frame.contentWindow,'wrong-channel');await new Promise(r=>setTimeout(r,0));assert.equal(calls,0);
  send('https://engine.example',frame.frame.contentWindow);await new Promise(r=>setTimeout(r,0));assert.equal(calls,1);assert.equal(messages[0].origin,'https://engine.example');assert.equal(messages[0].data.ticket,'signed-ticket');
  send('https://engine.example',frame.frame.contentWindow,frame.channel,'started');await frame.ready;frame.destroy();assert.equal(controller.frames.size,0);dom.window.close();
});
test('a failed account ticket reports an error to Orbit and marks the frame for a fresh retry',async()=>{
  const dom=new JSDOM('<div id="frames"></div>',{url:'https://app.example',runScripts:'outside-only'}),w=dom.window;
  w.currentAccount=()=>({engine:'https://engine.example'});w.api=async()=>{throw new Error('Please sign in again.');};w.migrateOwner=()=>Promise.resolve();
  const source=(await fs.readFile(new URL('../src/remote-engine.js',import.meta.url),'utf8')).replace(/^import .+;\s*$/gm,'').replace('export class RemoteController','window.RemoteController = class RemoteController');w.eval(source);const controller=new w.RemoteController(),frame=controller.createFrame();w.document.body.append(frame.frame);let reported;
  frame.addEventListener('error',event=>reported=event.message);const ready=assert.rejects(frame.ready,/sign in again/);
  w.dispatchEvent(new w.MessageEvent('message',{origin:'https://engine.example',source:frame.frame.contentWindow,data:{channel:frame.channel,type:'ready'}}));
  await ready;assert.equal(reported,'Please sign in again.');assert.equal(frame.failed,true);frame.destroy();dom.window.close();
});
