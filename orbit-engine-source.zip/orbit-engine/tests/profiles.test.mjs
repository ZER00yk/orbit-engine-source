import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
import {JSDOM} from 'jsdom';
import {indexedDB,IDBDatabase,IDBObjectStore,IDBRequest,IDBCursorWithValue,IDBCursor,IDBIndex,IDBTransaction} from 'fake-indexeddb';
import {token} from '../server/account-crypto.mjs';
const bundle=await fs.readFile(new URL('../public/profile-runtime.js',import.meta.url),'utf8');
const raw=await fs.readFile(new URL('../public/scram/scramjet.all.js',import.meta.url),'utf8');
const result=r=>new Promise((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
test('the shipped website IndexedDB hook keeps open, deletion and enumeration in one account namespace',async()=>{
  const doms=[launch(),launch()],site=new URL('https://vel.gg/bo1z/'),names=[];
  try{
    for(const dom of doms){
      const w=dom.window;w.OrbitProfile.configure({id:token(),key:token()});
      w.eval(raw.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='));
      const hooks=new Map();w.__testRequire(4338).default({url:site,Proxy(name,options){hooks.set(name,options.apply);},Trap(){}});
      const open={args:['saves']};hooks.get('IDBFactory.prototype.open')(open);names.push(open.args[0]);
      assert.equal(open.args[0],w.OrbitProfile.dbName('https://vel.gg@saves'));
      const remove={args:['saves']};hooks.get('IDBFactory.prototype.deleteDatabase')(remove);assert.equal(remove.args[0],open.args[0]);
      let list;hooks.get('IDBFactory.prototype.databases')({call:()=>Promise.resolve([{name:open.args[0],version:1},{name:'https://vel.gg@legacy',version:1},{name:'orbit:another-account:https://vel.gg@saves',version:1}]),return(value){list=value;}});
      assert.deepEqual(JSON.parse(JSON.stringify(await list)),[{name:'saves',version:1}]);
    }
    assert.notEqual(names[0],names[1]);
  }finally{for(const dom of doms)dom.window.close();}
});
function launch(shared){const dom=new JSDOM('',{url:'https://engine.example',runScripts:'outside-only'});if(shared)Object.defineProperty(dom.window,"localStorage",{value:shared,writable:true,configurable:true});Object.assign(dom.window,{TextEncoder,TextDecoder});dom.window.eval(bundle);return dom;}
test('encrypted DOM storage preserves PokéRogue missing-key behavior and isolates two people on one device',()=>{
  const dom=launch(),w=dom.window,native=w.localStorage,a={id:token(),key:token()},b={id:token(),key:token()};w.OrbitProfile.configure(a);
  w.eval(raw.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='));
  const factory=w.__testRequire(5289).default;factory({url:new URL('https://pokerogue.net/')},w);
  assert.equal(Object.hasOwn(w.localStorage,'settings'),false);assert.equal(w.localStorage.getItem('settings'),null);w.localStorage.setItem('login','private-session');w.localStorage.setItem('settings','{"volume":2}');
  assert.equal(w.localStorage.key(0),'login');assert.equal(w.localStorage.length,2);assert.equal(Object.values(native).some(v=>v.includes('private-session')),false);
  assert.throws(()=>w.OrbitProfile.configure(b));const second=launch(native),wb=second.window;wb.OrbitProfile.configure(b);const other=new wb.Proxy(native,wb.OrbitProfile.storageHandler('pokerogue.net'));assert.equal(other.getItem('login'),null);other.setItem('login','other-session');other.clear();second.window.close();
  assert.equal(w.localStorage.getItem('login'),'private-session');assert.equal(w.localStorage.getItem('settings'),'{"volume":2}');dom.window.close();
});
test('cookie jars are authenticated ciphertext and a different account key cannot read them',()=>{
  const dom=launch(),p=dom.window.OrbitProfile,a={id:token(),key:token()},b={id:token(),key:token()};p.configure(a);const cookie={session:{name:'session',value:'account-token',domain:'pokerogue.net',path:'/'}};const sealed=p.cookieSeal(cookie);assert.equal(sealed.includes('account-token'),false);assert.deepEqual(JSON.parse(JSON.stringify(p.cookieDump(sealed))),cookie);const second=launch(),pb=second.window.OrbitProfile;pb.configure(b);assert.throws(()=>pb.cookieDump(sealed));second.window.close();assert.equal(p.cookieDump(sealed).session.value,'account-token');dom.window.close();
});
test('IndexedDB records encrypt session values while preserving indexed keys, binary data and cursor updates',async()=>{
  const names=new WeakMap(),cursorValues=new WeakMap();Object.defineProperty(IDBDatabase.prototype,'name',{configurable:true,get(){return names.get(this)},set(v){names.set(this,v)}});Object.defineProperty(IDBCursorWithValue.prototype,'value',{configurable:true,get(){return cursorValues.get(this)},set(v){cursorValues.set(this,v)}});const nativeResult=Object.getOwnPropertyDescriptor(IDBRequest.prototype,'result').get;const local={},context=vm.createContext({TextEncoder,TextDecoder,crypto:globalThis.crypto,atob,btoa,console,Uint8Array,ArrayBuffer,DataView,Date,Map,Set,DOMException,IDBDatabase,IDBObjectStore,IDBRequest,IDBCursorWithValue,IDBCursor,IDBIndex,IDBTransaction,localStorage:local,sessionStorage:{}});vm.runInContext(bundle,context);const p=context.OrbitProfile;p.configure({id:token(),key:token()});
  const request=indexedDB.open(p.dbName('https://game.example@state'));request.onupgradeneeded=()=>{const store=request.result.createObjectStore('save',{keyPath:'id'});store.createIndex('name','name');};const db=await result(request);
  const value={id:1,name:'slot',token:'do-not-share',bytes:new Uint8Array([1,2,3])};await result(db.transaction('save','readwrite').objectStore('save').put(value));
  const saved=await result(db.transaction('save').objectStore('save').get(1));assert.equal(saved.token,'do-not-share');assert.deepEqual(Array.from(saved.bytes),[1,2,3]);const indexed=await result(db.transaction('save').objectStore('save').index('name').get('slot'));assert.equal(indexed.token,'do-not-share');
  const read=db.transaction('save').objectStore('save').get(1);await result(read);const rawRecord=nativeResult.call(read);assert.equal(rawRecord.token,undefined);assert.equal(JSON.stringify(rawRecord).includes('do-not-share'),false);const second=launch(),pb=second.window.OrbitProfile;pb.configure({id:token(),key:token()});assert.throws(()=>pb.open(rawRecord.__orbit_private_record,'idb:'+db.name+':save'));second.window.close();db.close();
});
