import WebSocket from 'ws';
import {HttpsProxyAgent} from 'https-proxy-agent';
import {Duplex} from 'node:stream';
import tls from 'node:tls';
const address=process.argv[2]||'wss://wisp.mercurywork.shop/';
const target=process.argv[3]||'example.org';
const proxy=process.env.HTTPS_PROXY||process.env.HTTP_PROXY;
const ws=new WebSocket(address,{agent:proxy?new HttpsProxyAgent(proxy):undefined,handshakeTimeout:15000});
function packet(type,id,data=Buffer.alloc(0)){const header=Buffer.alloc(5);header[0]=type;header.writeUInt32LE(id,1);return Buffer.concat([header,data]);}
let tunnel,secure,started=false,content='';
await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>finish(new Error('Relay browsing test timed out.')),25000);
  let done=false;
  const finish=error=>{if(done)return;done=true;clearTimeout(timer);secure?.destroy();ws.close();if(error)reject(error);else resolve();};
  ws.on('error',finish);ws.on('close',()=>{if(!done)finish(new Error('Relay closed before the HTTPS response.'));});
  ws.on('message',message=>{
    const data=Buffer.from(message);if(data.length<5)return;const type=data[0],id=data.readUInt32LE(1);
    if(type===3 && id===0 && !started){
      started=true;const info=Buffer.alloc(3);info[0]=1;info.writeUInt16LE(443,1);ws.send(packet(1,1,Buffer.concat([info,Buffer.from(target)])));
      tunnel=new Duplex({read(){},write(chunk,encoding,callback){if(ws.readyState!==WebSocket.OPEN){callback(new Error('Relay disconnected.'));return;}ws.send(packet(2,1,chunk),callback);}});
      secure=tls.connect({socket:tunnel,servername:target,rejectUnauthorized:true},()=>secure.write(`GET / HTTP/1.1\r\nHost: ${target}\r\nConnection: close\r\n\r\n`));
      secure.on('data',chunk=>{content+=chunk.toString();});secure.on('error',finish);secure.on('end',()=>finish());
    }else if(type===2 && id===1){tunnel?.push(data.subarray(5));ws.send(packet(3,1,Buffer.from([0x80,0,0,0])));}else if(type===4 && id===1){tunnel?.push(null);}
  });
});
if(!/^HTTP\/1\.[01] 200/.test(content) || !content.includes('Example Domain'))throw new Error('The relay did not return the expected website.');
console.log(JSON.stringify({relay:address,website:`https://${target}/`,tlsCertificateVerified:true,httpStatus:200,contentVerified:true}));
