import WebSocket from 'ws';
import {HttpsProxyAgent} from 'https-proxy-agent';
import {loadTransport} from './transport-harness.mjs';

const relay=process.argv[2]||'wss://wisp.mercurywork.shop/';
const proxy=process.env.HTTPS_PROXY||process.env.HTTP_PROXY;
const agent=proxy?new HttpsProxyAgent(proxy):undefined;
class NetworkSocket extends WebSocket {constructor(url,protocols){super(url,protocols,{agent,handshakeTimeout:15000});}}
const Transport=await loadTransport({WebSocket:NetworkSocket,instantiateDelay:25});
const client=new Transport({websocket:relay});
const checks=[];
async function fetchPage(url,expectedStatus=200){
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),25000);
  try{
    if(!client.ready)await client.init();
    const response=await client.request(new URL(url),'GET',undefined,{
      'user-agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36',
      'accept':'*/*','origin':'https://pokerogue.net',
    },abort.signal);
    const body=await new Response(response.body).text();
    if(response.status!==expectedStatus)throw new Error(`${url} returned ${response.status}; expected ${expectedStatus}.`);
    checks.push({url,status:response.status,bytes:body.length});
    return body;
  }finally{clearTimeout(timer);}
}
try{
  // Start these together while WASM is still loading, as a game does.
  const [html,example,account]=await Promise.all([
    fetchPage('https://pokerogue.net/'),fetchPage('https://example.org/'),
    fetchPage('https://api.pokerogue.net/account/info',401),
  ]);
  if(!html.includes('id="app"') || !example.includes('Example Domain') || !account.includes('missing token'))throw new Error('Unexpected website response.');
  const script=html.match(/<script[^>]+type="module"[^>]+src="([^"]+)/)?.[1];
  if(!script)throw new Error('Game entry module was not found.');
  const entry=new URL(script,'https://pokerogue.net/');
  const javascript=await fetchPage(entry.href);
  const imports=[...new Set([...javascript.matchAll(/\bfrom["']([^"']+)["']/g)].map(match=>match[1]).filter(path=>path.startsWith('./')))];
  if(!imports.length)throw new Error('Game startup dependencies were not found.');
  await Promise.all(imports.map(path=>fetchPage(new URL(path,entry).href)));
  console.log(JSON.stringify({relay,checks,parallelColdStartup:true,interactiveGameplayVerified:false}));
  process.exit(0);
}catch(error){console.error(error.message);process.exit(1);}
