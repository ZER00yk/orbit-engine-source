import { mkdir } from 'node:fs/promises';
import {build} from 'esbuild';
await mkdir('dist/server', {recursive:true});
await build({entryPoints:['server/worker.mjs'],outfile:'dist/server/index.js',bundle:true,format:'esm',platform:'neutral',external:['node:crypto'],target:'es2022'});
console.log('Worker entrypoint ready.');
