// Pinned patches are deliberately asserted so an upstream update fails closed.
function replace(source,needle,value){if(!source.includes(needle))throw new Error('Profile patch no longer matches Scramjet: '+needle.slice(0,70));return source.replace(needle,value);}
export function patchScramjetProfiles(source){
  source=source.replace(/5289:function\(e,t,r\)\{[\s\S]*?(?=\},\d+:function)/,`5289:function(e,t,r){function n(e,t){let l=new Proxy(t.localStorage,globalThis.OrbitProfile.storageHandler(e.url.host)),s=new Proxy(t.sessionStorage,globalThis.OrbitProfile.storageHandler(e.url.host,true));delete t.localStorage;delete t.sessionStorage;t.localStorage=l;t.sessionStorage=s}r.r(t),r.d(t,{default:()=>n})`);
  if(!source.includes('storageHandler(e.url.host)'))throw new Error('Storage profile patch missing');
  // Scope controller, worker and client cookie DBs identically.
  const count=source.match(/"\$scramjet"/g)?.length;if(!count||count<4)throw new Error('Engine database names changed');
  source=source.replaceAll('"$scramjet"','globalThis.OrbitProfile.dbName("$scramjet")');
  source=replace(source,'this.cookieStore.load(t)','this.cookieStore.load(globalThis.OrbitProfile.cookieDump(t))');
  source=source.replaceAll('JSON.parse(d.dump())','globalThis.OrbitProfile.cookieSeal(JSON.parse(d.dump()))');
  source=source.replaceAll('JSON.parse(this.cookieStore.dump())','globalThis.OrbitProfile.cookieSeal(JSON.parse(this.cookieStore.dump()))');
  // Persisted JS document.cookie updates use the same encrypted jar.
  source=source.replaceAll('JSON.parse(e.cookieStore.dump())','globalThis.OrbitProfile.cookieSeal(JSON.parse(e.cookieStore.dump()))');
  source=replace(source,'return[t(c.$W.files.wasm),t(c.$W.files.all),t("data:application/javascript;base64,"+i)]','return[t("/profile-runtime.js?v=4"),t(c.$W.files.wasm),t(c.$W.files.all),t("data:application/javascript;base64,"+i)]');
  source=replace(source,'self.COOKIE = ${r};','${globalThis.OrbitProfile.bootstrap()}\nself.COOKIE = ${r};');
  source=replace(source,'l("wasm"),l("all"),s+=`$scramjetLoadClient()', '(o?s+=`import "/profile-runtime.js?v=4"\n`:s+=`importScripts("/profile-runtime.js?v=4");\n`),l("wasm"),l("all"),s+=globalThis.OrbitProfile.bootstrap(),s+=`$scramjetLoadClient()');
  // Static module dependencies execute before the entry module's body. Install
  // the private profile and proxy hooks as an earlier dependency, so imported
  // game modules can use storage and import.meta during their initialization.
  source=replace(source,'s+=globalThis.OrbitProfile.bootstrap(),s+=`$scramjetLoadClient().loadAndHook(${JSON.stringify(n.$W)});`;','(()=>{let b=globalThis.OrbitProfile.bootstrap()+`$scramjetLoadClient().loadAndHook(${JSON.stringify(n.$W)});`;s+=o?`import ${JSON.stringify("data:application/javascript;base64,"+btoa(new TextEncoder().encode(b).reduce((v,c)=>v+String.fromCharCode(c),"")))};\n`:b})();');
  // The pinned rewriter misses import.meta inside functions. Restore each
  // module's virtual URL before its code runs, including graphics workers and
  // Emscripten's relative WASM / pthread resources. Classic scripts stay intact.
  source=replace(source,'return l}catch(a){if(console.warn("failed rewriting js for"','l=globalThis.OrbitProfile.rewriteJS(l,t||r.base.href,n.$W.globals.importfn);return o?"import.meta.url="+JSON.stringify(t||r.base.href)+";\\n"+(l instanceof Uint8Array?new TextDecoder().decode(l):l):l}catch(a){if(console.warn("failed rewriting js for"');
  // Preserve import options and native asynchronous error behavior. A computed
  // root-relative specifier belongs to the website, never to the engine server.
  source=replace(source,'let r=e.natives.call("Function",null,"url","return import(url)");','let r=e.natives.call("Function",null,"url","options","return import(url,options)");');
  source=replace(source,'value:function(t,n){let a=new URL(n,t).href;return n.includes(":")||n.startsWith("/")||n.startsWith(".")||n.startsWith("..")?r(`${(0,i.Oy)(a,e.meta)}?type=module`):r(n)}','value:function(t,n,o){return Promise.resolve().then(()=>{if(typeof n==="symbol")throw new TypeError("A module specifier cannot be a Symbol");n=String(n);let a=new URL(n,t).href;return n.includes(":")||n.startsWith("/")||n.startsWith(".")||n.startsWith("..")?r(`${(0,i.Oy)(a,e.meta)}?type=module`,o):r(n,o)})}');
  // Upstream scopes open() only. Scope deletion and enumeration too.
  source=replace(source,'`${e.url.origin}@${t.args[0]}`','globalThis.OrbitProfile.dbName(`${e.url.origin}@${t.args[0]}`)');
  source=replace(source,'t.substring(t.indexOf("@")+1)','globalThis.OrbitProfile.visibleDBName(t)');
  source=replace(source,'function n(e){e.Proxy("IDBFactory.prototype.open"','function n(e){e.Proxy("IDBFactory.prototype.deleteDatabase",{apply(t){t.args[0]=globalThis.OrbitProfile.dbName(`${e.url.origin}@${t.args[0]}`)}});e.Proxy("IDBFactory.prototype.databases",{apply(t){let r=t.call();t.return(r.then(v=>v.filter(x=>x.name.startsWith(globalThis.OrbitProfile.dbName(e.url.origin+"@"))).map(x=>({...x,name:globalThis.OrbitProfile.visibleDBName(x.name)}))))}});e.Proxy("IDBFactory.prototype.open"');
  source=replace(source,'e.Proxy("IDBFactory.prototype.open",{apply(t){t.args[0]=`${e.url.origin}@${t.args[0]}`}})','e.Proxy("IDBFactory.prototype.open",{apply(t){t.args[0]=globalThis.OrbitProfile.dbName(`${e.url.origin}@${t.args[0]}`)}})');
  // Replace upstream's origin-only directory with authenticated, account- and
  // website-scoped encrypted OPFS, including synchronous game-worker access.
  const files='6593:function(e,t,r){function n(e){e.Proxy("StorageManager.prototype.getDirectory",{apply(t){let r=t.call();t.return((async()=>{let t=await r,n=await t.getDirectoryHandle(`${e.url.origin.replace(/\\/|\\s|\\./g,"-")}`,{create:!0});return Object.defineProperty(n,"name",{value:"",writable:!1}),n})())}})}r.r(t),r.d(t,{default:()=>n})}';
  // Games and polyfills create empty helper frames. about:blank/srcdoc inherit
  // their creator's website; a standalone opaque document has no file scope.
  // Installing hooks must not parse the literal "null" origin as a URL or
  // abort startup. Deny opaque file requests without exposing the native root.
  source=replace(source,files,'6593:function(e,t,r){var a=r(2794);function s(e){let t=e.url;if("about:"===t.protocol&&("blank"===t.pathname||"srcdoc"===t.pathname)){try{let r=e.global.parent;if(r&&r!==e.global&&r[a.pX])t=r[a.pX].url}catch{return null}}return /^https?:\\/\\//.test(t.origin)?t.origin:null}function n(e){let r=s(e);r&&globalThis.OrbitProfile.filesOrigin(r);e.Proxy("StorageManager.prototype.getDirectory",{apply(t){t.return(r?globalThis.OrbitProfile.filesDirectory(r):Promise.reject(new DOMException("Private file storage is unavailable for this document.","SecurityError")))}})}r.r(t),r.d(t,{default:()=>n})}');
  // A native popup loses Orbit's shell and partitioned browsing session. Send
  // addressed popups to the owning Orbit tab instead. Returning null keeps the
  // normal blocked-popup contract; no fake opener or authentication is created.
  source=replace(source,'e.Proxy("window.open",{apply(t){t.args[0]&&',
    'e.Proxy("window.open",{apply(t){let target=String(t.args[1]||"_blank");if(!["_self","_parent","_top","_unfencedTop"].includes(target)&&e.frame){let url="";try{let value=new URL(String(t.args[0]||"about:blank"),e.url);if(["http:","https:"].includes(value.protocol)&&!value.username&&!value.password)url=value.href}catch{}let event=new Event("orbit-open-tab");event.url=url;e.frame.dispatchEvent(event);return t.return(null)}t.args[0]&&');
  return source;
}
