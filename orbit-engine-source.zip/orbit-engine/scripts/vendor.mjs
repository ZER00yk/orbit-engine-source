import { cp, mkdir, access, copyFile, readFile, writeFile } from 'node:fs/promises';
import { scramjetPath } from '@mercuryworkshop/scramjet/path';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { baremuxPath } from '@mercuryworkshop/bare-mux/node';
import { patchScramjetStorage, patchScramjetWorker, patchScramjetCookies } from './scramjet-patches.mjs';
import {patchScramjetProfiles} from './profile-patches.mjs';
import {patchLibcurlExports} from './libcurl-patches.mjs';
import {build} from 'esbuild';
const libcurlPath=dirname(fileURLToPath(import.meta.resolve('@mercuryworkshop/libcurl-transport')));
for (const [source, target] of [[scramjetPath,'scram'],[libcurlPath,'libcurl'],[baremuxPath,'baremux']]) {
  await access(source);
  await mkdir(`public/${target}`, {recursive:true});
  await cp(source, `public/${target}`, {recursive:true});
}
await writeFile('public/libcurl/index.mjs',patchLibcurlExports(await readFile('public/libcurl/index.mjs','utf8')));
await writeFile('public/scram/scramjet.all.js',patchScramjetProfiles(patchScramjetCookies(patchScramjetWorker(patchScramjetStorage(await readFile('public/scram/scramjet.all.js','utf8'))))));
await build({entryPoints:['src/profile-runtime.js'],outfile:'public/profile-runtime.js',bundle:true,format:'iife',platform:'browser',target:'es2022'});
const hosts=await readFile('public/adblock-hosts.txt','utf8');
const adHosts=[...new Set([...hosts.matchAll(/^127\.0\.0\.1\s+([a-z0-9.-]+)\s*$/gm)].map(match=>match[1]))];
if(adHosts.length<1000)throw new Error('The bundled ad-blocking list is missing or invalid.');
await writeFile('public/adblock-hosts.js','/* Peter Lowe’s ad/tracker list: https://pgl.yoyo.org/adservers/ — see adblock-hosts.txt for credits and source. */\nself.ORBIT_AD_HOSTS=new Set('+JSON.stringify(adHosts)+');\n');
await copyFile('THIRD_PARTY_NOTICES.md','public/third-party-notices.txt');
await mkdir('public/licenses',{recursive:true});
for(const name of ['scramjet','bare-mux','libcurl-transport','wisp-js']){
  try{await copyFile(`node_modules/@mercuryworkshop/${name}/LICENSE`,`public/licenses/${name}.txt`);}catch{}
}
console.log('Vendored official browser assets.');
