import vm from 'node:vm';
import {readFile} from 'node:fs/promises';

// Native API simulator: tests exercise the shipped encrypted runtime, not an
// alternative implementation of its cipher, offsets or profile scoping.
const bundle=await readFile(new URL('../public/profile-runtime.js',import.meta.url),'utf8');
const scram=await readFile(new URL('../public/scram/scramjet.all.js',import.meta.url),'utf8');
const err=name=>new DOMException(name,name);
export function disk(){return {root:{name:'',kind:'directory',children:new Map()},locks:new Map(),snapshotReads:0};}
export function realm(shared,profile,origin='https://vel.gg',creatorOrigin){
  class FileSystemHandle{
    constructor(node){this.node=node;}
    get name(){return this.node.name;}
    get kind(){return this.node.kind;}
    async isSameEntry(other){return this.node===other.node;}
    async queryPermission(){return 'granted';}
    async requestPermission(){return 'granted';}
  }
  function child(parent,name,kind,options){name=String(name);if(!name||name==='.'||name==='..'||name.includes('/'))throw new TypeError('Invalid file name');let node=parent.children.get(name);if(!node){if(!options?.create)throw err('NotFoundError');node={name,kind,...(kind==='directory'?{children:new Map()}:{data:new Uint8Array(),active:new Set()})};parent.children.set(name,node);}if(node.kind!==kind)throw err('TypeMismatchError');return node;}
  class FileSystemDirectoryHandle extends FileSystemHandle{
    async getDirectoryHandle(name,options){return new FileSystemDirectoryHandle(child(this.node,name,'directory',options));}
    async getFileHandle(name,options){return new FileSystemFileHandle(child(this.node,name,'file',options));}
    async *entries(){for(const [name,node]of this.node.children)yield [name,node.kind==='file'?new FileSystemFileHandle(node):new FileSystemDirectoryHandle(node)];}
    async removeEntry(name,options){const node=this.node.children.get(name);if(!node)throw err('NotFoundError');if(node.kind==='directory'&&node.children.size&&!options?.recursive)throw err('InvalidModificationError');this.node.children.delete(name);}
    async resolve(handle){function find(node,path){if(node===handle.node)return path;if(node.children)for(const [name,child]of node.children){const result=find(child,[...path,name]);if(result)return result;}return null;}return find(this.node,[]);}
  }
  function asBytes(value){if(ArrayBuffer.isView(value))return new Uint8Array(value.buffer,value.byteOffset,value.byteLength);return new Uint8Array(value);}
  function extend(node,length){if(node.data.length<length){const data=new Uint8Array(length);data.set(node.data);node.data=data;}}
  class FileSystemSyncAccessHandle{
    constructor(node,mode){this.node=node;this.mode=mode;this.closed=false;node.active.add(this);}
    valid(write=false){if(this.closed)throw err('InvalidStateError');if(write&&this.mode==='read-only')throw err('NoModificationAllowedError');}
    getSize(){this.valid();return this.node.data.length;}
    read(buffer,{at=0}={}){this.valid();const out=asBytes(buffer),n=Math.min(out.length,Math.max(0,this.node.data.length-at));out.set(this.node.data.subarray(at,at+n));return n;}
    write(buffer,{at=0}={}){this.valid(true);const input=asBytes(buffer);extend(this.node,at+input.length);this.node.data.set(input,at);return input.length;}
    truncate(length){this.valid(true);if(length>this.node.data.length)extend(this.node,length);else this.node.data=this.node.data.slice(0,length);}
    flush(){this.valid();}
    close(){this.closed=true;this.node.active.delete(this);}
  }
  class FileSystemFileHandle extends FileSystemHandle{
    async getFile(){const file=new File([this.node.data],this.node.name,{lastModified:1}),slice=file.slice.bind(file);file.slice=(...args)=>{shared.snapshotReads++;return slice(...args);};return file;}
    async createSyncAccessHandle(options={}){if(this.node.active.size)throw err('NoModificationAllowedError');return new FileSystemSyncAccessHandle(this.node,options.mode);}
    async createWritable({keepExistingData=false}={}){
      if(this.node.active.size)throw err('NoModificationAllowedError');const target=this.node,staged={data:keepExistingData?target.data.slice():new Uint8Array()};let cursor=0,closed=false;
      return {async write(value){if(closed)throw err('InvalidStateError');if(value?.type==='seek'){cursor=value.position;return;}if(value?.type==='truncate'){return this.truncate(value.size);}const at=value?.type==='write'?value.position??cursor:cursor,input=value?.type==='write'?value.data:value;const data=typeof input==='string'?new TextEncoder().encode(input):input instanceof Blob?new Uint8Array(await input.arrayBuffer()):asBytes(input);extend(staged,at+data.length);staged.data.set(data,at);cursor=at+data.length;},async truncate(length){if(closed)throw err('InvalidStateError');if(length>staged.data.length)extend(staged,length);else staged.data=staged.data.slice(0,length);},async close(){closed=true;target.data=staged.data;},async abort(){closed=true;}};
    }
  }
  class StorageManager{async getDirectory(){return new FileSystemDirectoryHandle(shared.root);}}
  class LockManager{
    async request(name,options,callback){if(typeof options==='function')callback=options;while(shared.locks.has(name))await shared.locks.get(name).released;let release;const released=new Promise(resolve=>release=resolve),lock={name,mode:'exclusive',clientId:'test'};shared.locks.set(name,{released,lock});try{return await callback(lock);}finally{shared.locks.delete(name);release();}}
    async query(){return {held:[...shared.locks.values()].map(x=>x.lock),pending:[]};}
  }
  const context=vm.createContext({console,TextEncoder,TextDecoder,URL,URLSearchParams,crypto:globalThis.crypto,atob,btoa,Uint8Array,ArrayBuffer,SharedArrayBuffer,DataView,Date,Map,Set,DOMException,File,Blob,ReadableStream,WritableStream,Response,Request,Headers,performance,Event,EventTarget,setTimeout,clearTimeout,localStorage:{},sessionStorage:{},FileSystemHandle,FileSystemDirectoryHandle,FileSystemFileHandle,FileSystemSyncAccessHandle,StorageManager,LockManager,navigator:{storage:new StorageManager(),locks:new LockManager(),userAgent:'test'}});
  vm.runInContext(bundle,context);context.OrbitProfile.configure(profile);
  vm.runInContext(scram.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='),context);
  let getDirectoryHook;
  context.parent=creatorOrigin?{[Symbol.for('scramjet client global')]:{url:new URL(creatorOrigin)}}:context;
  context.__testRequire(6593).default({global:context,url:new URL(origin),Proxy(name,options){if(name==='StorageManager.prototype.getDirectory')getDirectoryHook=options.apply;}});
  return {context,profile:context.OrbitProfile,async directory(){let returned;getDirectoryHook({return(value){returned=value;},call(){throw new Error('The unscoped native root must not be called by Scramjet');}});return returned;},unscoped(node){return node.kind==='file'?new FileSystemFileHandle(node):new FileSystemDirectoryHandle(node);}};
}
export function allFiles(node){return node.kind==='file'?[node]:[...node.children.values()].flatMap(allFiles);}
