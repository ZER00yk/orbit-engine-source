# Orbit

An invite-only browser with separate username/password accounts, tabs, bookmarks, history, search, page navigation, and downloads. Normal browsing runs through Scramjet's service worker and libcurl transport. It does not use a remote screenshot stream.

## Architecture

- The account UI and browsing runtime are hosted on different Site origins. Untrusted game pages cannot access the account origin’s HttpOnly session cookie or storage. The runtime keeps the pinned official Scramjet 1.1.0 / bare-mux / libcurl assets.
- libcurl transport 2.0.5 runs through a small bare-mux compatibility adapter. Parallel game requests share one initialization promise, so requests cannot start before WASM is ready or overwrite each other's readiness callback.
- The service worker rewrites proxied pages under `/browse/`.
- A checked build patch corrects Scramjet 1.1.0's storage property detection: missing settings keys report absent instead of returning a descriptor containing `null`. This prevents PokéRogue's settings migration from crashing at battle-scene startup. Existing per-site storage keys and saves are preserved.
- A second checked patch separates proxy-engine readiness from configuration availability. Configuration messages received before the first fetch no longer skip shared configuration or WASM initialization. Concurrent requests await the same startup promise, and failed initialization can retry.
- Cookie compatibility fixes restore the actual IndexedDB cookie object before requests or cookie messages run, persist response cookies, and send their values to the page. Cookies stay within the exact domain or its subdomains. Worker suspension and restart no longer discard the cookie jar.
- The transport retries DNS, connection, and TLS-handshake failures at most twice, preserving upload bytes and headers. It does not retry HTTP errors, certificate verification failures, timeouts, send errors, or receive errors that could duplicate a committed game save or guess.
- `/wisp/` forwards WebSocket traffic to a configured Wisp server. HTTPS websites use libcurl's TLS connection through the relay.
- The first deployment uses the shared `wss://wisp.mercurywork.shop/` relay. This server is operated by a third party. Its availability and destination IP reputation are outside this project's control.
- If the relay reports a hostname as unreachable, the transport retries using a short-lived public IPv4 answer from Google Public DNS over HTTPS. The authenticated engine performs this lookup without forwarding account credentials or a client subnet. TLS still verifies the original website hostname; relay policy blocks are not overridden.
- Both Site origins allow the login page to be opened without ChatGPT. Account APIs require an Orbit session, and the runtime and relay require a signed, short-lived ticket tied to an active Orbit session. WebSocket upgrades also check Origin. The account origin hosts no proxied pages or public relay.
- Accounts, one-use invitations, hashed sessions and encrypted UI profiles persist in D1. Each query enforces session ownership. Tabs, bookmarks, history and settings sync with the account. Game sessions and saves remain device-local, separated by account; credential-bearing DOM storage, cookies, IndexedDB record payloads and cache response bodies use a per-account AES-GCM key. The master derivation key stays on the server. IndexedDB keys/index fields and cache URLs remain searchable metadata.
- Passwords use salted scrypt (N=16384, r=8, p=5). Session tokens are random, stored hashed, and set in a Secure HttpOnly SameSite=Strict host cookie. The owner setup token is random, hashed in runtime secrets, single-use through the unique owner constraint, and passed in a URL fragment. No public first-user/admin bootstrap exists.
- The owner creates one-use invitations in Settings. They expire after seven days. Members cannot create invitations or read other accounts’ profiles. Logout revokes the current session. Password changes revoke other sessions. A browser switches accounts by replacing the worker realm and removing open game frames.
- On the owner’s first login on the original device, legacy bookmarks/settings, localStorage, cookie jars and game IndexedDB records are copied into the owner profile. Source data is retained until the encrypted destination acknowledges import; members never receive this migration.

## Browser controls

- The fullscreen button hides Orbit’s tabs, toolbar, bookmarks and status bar, and requests native browser fullscreen. The corner restore button, Escape, or Ctrl+Shift+F brings the controls back. If native fullscreen is unavailable, the controls still collapse. The active iframe stays mounted, preserving ongoing games.
- Dark is the default theme. Settings also offers Light, compact controls, bookmark/status visibility, reduced animation, search engine choice, history recording and reopening tabs on launch.
- Free ad/tracker blocking uses a bundled snapshot of Peter Lowe’s domain list. Scramjet’s request event returns an empty response for listed domains before their actual request goes through the transport. Top-level document navigation is allowed. This does not filter first-party or all video ads, and it does not inject cosmetic rules into game pages.
- Blocking can be turned off globally or allowed for the current website. These settings belong to the authenticated profile; the blocking policy is persisted through Scramjet’s existing configuration API so it survives service-worker restarts. Settings changes never automatically reload a running game. Reload a page manually to apply blocking to content already loaded.
- The original blocklist is in `public/adblock-hosts.txt`; the normal asset preparation step compiles it into a small JavaScript Set. No external blocklist service is contacted while browsing. Update that reviewed snapshot to refresh rules.

## Build

Use Node.js 22 or newer:

```sh
npm ci
npm run build
```

`scripts/vendor.mjs` copies the pinned official browser assets into `public/` and applies the reviewed storage, worker startup, and cookie compatibility patches in `scripts/scramjet-patches.mjs`. It refuses to build if the expected upstream implementations change. Vite produces `dist/client`, and `scripts/build-worker.mjs` produces `dist/server/index.js`. The deployment includes both directories. The Worker expects the standard `ASSETS` binding.

`npm run dev` runs the frontend. The managed preview starts it through `sites-preview`, rather than starting a separate development server manually.

## Dedicated private Wisp relay

`server/relay.mjs` is a ready-to-deploy Node server. It requires an HTTPS hosting service that supports persistent WebSockets and outbound TCP connections. The Site's Worker host cannot run this server directly.

Set on the relay host:

- `RELAY_TOKEN`: a securely generated random secret of at least 32 characters.
- `RELAY_ALLOWED_ORIGIN`: the exact HTTPS origin of the Orbit site.
- `PORT`: supplied by the host, or `8080`.

Run `npm run relay`, or build `Dockerfile.relay`. The Compose example binds only to localhost and must sit behind an HTTPS reverse proxy. The health endpoint is `/health`; the WebSocket endpoint is `/wisp/`.

Set production Site environment values:

- `WISP_UPSTREAM`: `https://your-relay.example/wisp/`
- `WISP_TOKEN`: the relay's `RELAY_TOKEN`, stored as a secret.

Deploy a new Site version after changing these values. The Worker supplies the bearer token and permitted Origin to the relay; the secret is never sent to the browser. The private relay rejects unauthorized clients, local/private destinations, and ports other than 80/443. UDP is disabled.

The Settings panel can also select a WSS server that allows direct browser connections. That choice is saved to the authenticated profile. For the dedicated private server above, use the Site environment configuration so its secret stays server-side.

## Verification

```sh
npm test
node scripts/check-relay.mjs
node --experimental-vm-modules scripts/check-game.mjs
```

The relay check requests `https://example.org/` through Wisp, validates the destination TLS certificate, and checks the returned HTTP status and page text. The tests cover address handling, persisted UI interactions, navigation race handling, the Worker relay boundary, and private-relay authentication.

No claim is made that every login, video provider, CAPTCHA, game, or website works. Compatibility must be checked per website. An interactive browser test of the hosted Scramjet flow was unavailable in the current authoring environment.

The game-loading update also waits for the service worker to control the page, leaves Orbit assets outside proxy interception, disables Scramjet's debugging source maps and error-capture wrappers, and ignores initial empty iframe loads. Real libcurl/Wisp checks reached PokéRogue's HTML and startup modules (HTTP 200) and its account endpoint (the expected HTTP 401 without a login token). This validates networking and startup; it does not prove a complete interactive game session.

PokéRogue startup diagnostics now observe its loader without completing, skipping, or retrying assets. If startup stalls, the status bar and Settings → Loading details show the pending public asset names and redacted error. Up to eight brief reports per navigation are sent to Orbit's account-protected `/api/game-diagnostics` endpoint, so the owner can inspect Worker logs without DevTools. Cookies, tokens, saved games, and browsing history are excluded. Reports are not stored in browsing state. The HTTP-only internal preview cannot run the secure-context service worker and SharedArrayBuffer features needed by this proxy; gameplay remains unverified there.

## Licenses

Scramjet is MIT licensed. bare-mux, libcurl transport, and Wisp have their upstream licenses; the browser assets and their source links are retained in `THIRD_PARTY_NOTICES.md`. Upstream source maps remain with the vendored bundles.

## Account deployment

The account Site needs logical D1 binding `DB` and these runtime values: `ORBIT_ENGINE_ORIGIN`, secret `ORBIT_TICKET_SECRET`, secret `ORBIT_PROFILE_SECRET`, and secret `ORBIT_SETUP_HASH`. Generate setup/ticket/profile secrets independently using 32 random bytes. The setup hash is SHA-256 of the one-use setup token. Never put these secrets in source or local environment files.

The engine Site has no database binding. It needs `ORBIT_MODE=engine`, `ORBIT_APP_ORIGIN`, and the same secret `ORBIT_TICKET_SECRET`. The engine checks ticket revocation against the account Site before bootstrapping or opening a relay connection. Public access is applied only after these protections are deployed.

The account schema is in `db/schema.ts`; reviewed Drizzle migrations are checked in under `drizzle/`. Runtime code never creates schema. After changes generate a new migration with `npx drizzle-kit generate`. Do not rewrite applied migrations.

The encryption hooks preserve object-store/index key paths, typed arrays, dates, Maps and Sets. Blob values in IndexedDB and OPFS are currently rejected rather than persisted unencrypted. Websites depending on those APIs may require a compatibility follow-up. The app does not provide password recovery; keep your Orbit password safely. Runtime key delivery and authorization assume a trusted server administrator. People with access to an already signed-in device can use its active session; sign out on shared devices.
