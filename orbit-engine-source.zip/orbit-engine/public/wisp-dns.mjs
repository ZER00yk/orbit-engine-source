import {publicHostname,publicIPv4} from './dns-policy.mjs?v=1';

function waitForLookup(promise,signal){
  if(!signal)return promise;
  signal.throwIfAborted();
  return new Promise((resolve,reject)=>{
    const abort=()=>{cleanup();reject(signal.reason||new DOMException('The operation was aborted.','AbortError'));};
    const cleanup=()=>signal.removeEventListener('abort',abort);
    signal.addEventListener('abort',abort,{once:true});
    promise.then(value=>{cleanup();resolve(value);},error=>{cleanup();reject(error);});
  });
}
export function createDnsTransport(WispWebSocket){
  const addresses=new Map(),unreachable=new Map(),pending=new Map();
  class Socket extends WispWebSocket {
    constructor(url,protocols){
      const lastSlash=url.lastIndexOf('/'),[hostname,port]=url.slice(lastSlash+1).split(':');
      let resolved=addresses.get(hostname);
      if(resolved&&resolved.until<=Date.now()){addresses.delete(hostname);resolved=null;}
      // Only the TCP destination changes. Curl retains the original HTTPS URL,
      // TLS server name, certificate checks, HTTP Host header and cookie origin.
      super(resolved?url.slice(0,lastSlash+1)+resolved.address+':'+port:url,protocols);
      this.addEventListener('close',event=>{
        // Wisp 0x42 means the server could not reach the host. Never override a
        // deliberate HostBlocked (0x48), throttling or other relay policy error.
        if(event.code===0x42&&publicHostname(hostname)){
          unreachable.set(hostname,resolved?.address||null);
          if(unreachable.size>64)unreachable.delete(unreachable.keys().next().value);
        }
      });
    }
  }
  async function recover(hostname,signal){
    signal?.throwIfAborted();
    if(!unreachable.has(hostname)&&!pending.has(hostname))return false;
    const attempted=unreachable.get(hostname);unreachable.delete(hostname);
    const cached=addresses.get(hostname);
    // A late failure from an earlier hostname connection can share the fresh
    // answer already obtained for another request on the same page.
    if(cached&&cached.until>Date.now()&&attempted!==cached.address)return true;
    if(!pending.has(hostname)){
      const lookup=(async()=>{
        try{
          const response=await fetch('/api/dns?hostname='+encodeURIComponent(hostname),{
            credentials:'include',cache:'no-store',redirect:'error',signal:AbortSignal.timeout(5000),
          });
          if(!response.ok)return false;
          const data=await response.json();
          if(data.hostname!==hostname||!Array.isArray(data.addresses)||!Number.isFinite(data.ttl)||data.ttl<1)return false;
          const candidates=data.addresses.filter(publicIPv4);
          if(!candidates.length)return false;
          const previous=addresses.get(hostname)?.address;
          const address=candidates.find(value=>value!==previous)||candidates[0];
          addresses.delete(hostname);addresses.set(hostname,{address,until:Date.now()+Math.min(data.ttl,300)*1000});
          if(addresses.size>64)addresses.delete(addresses.keys().next().value);
          return true;
        }catch{return false;}
      })().finally(()=>pending.delete(hostname));
      pending.set(hostname,lookup);
    }
    return waitForLookup(pending.get(hostname),signal);
  }
  return {Socket,recover};
}
