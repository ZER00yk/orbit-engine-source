// Report explicit upstream restrictions without altering challenges or account
// requests. Notices contain fixed categories and public hostnames only.
(()=>{
  function header(headers,name){const value=headers?.[name];return Array.isArray(value)?value.join(', '):String(value||'');}
  function notice(event){
    const url=event.url,document=['document','iframe'].includes(event.destination);
    if(!url)return null;
    if(document&&header(event.responseHeaders,'cf-mitigated')==='challenge')return {type:'orbit-site-challenge',site:url.hostname};
    if(document&&/(^|\.)youtube\.com$/.test(url.hostname)&&typeof event.responseBody==='string'&&
      /["']playabilityStatus["']\s*:\s*\{\s*["']status["']\s*:\s*["']LOGIN_REQUIRED["']\s*,\s*["']reason["']\s*:\s*["']Sign in to confirm you(?:’|\\u2019|')re not a bot["']/.test(event.responseBody))
      return {type:'orbit-youtube-restricted',site:url.hostname};
    if(document&&url.hostname==='accounts.google.com'&&/signin|oauth|servicelogin|login|^\/gsi\//i.test(url.pathname))
      return {type:event.status===403?'orbit-google-denied':'orbit-google-signin',site:'accounts.google.com'};
    if(url.hostname==='apis.roblox.com'&&url.pathname.startsWith('/account-recovery-service/')&&event.status===403&&
      header(event.responseHeaders,'rblx-challenge-type')&&!header(event.responseHeaders,'x-csrf-token'))
      return {type:'orbit-roblox-recovery-blocked',site:'roblox.com'};
    return null;
  }
  self.OrbitSiteStatus={notice};
})();
