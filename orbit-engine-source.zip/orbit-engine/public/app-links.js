(()=>{
  const escape=value=>String(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  function destination(address,prefix='/browse/'){
    try{const path=new URL(address).pathname;if(!path.startsWith(prefix))return null;return new URL(decodeURIComponent(path.slice(prefix.length)));}catch{return null;}
  }
  function response(url,document=true){
    // Scramjet serves embedded images, temporary downloads and graphics
    // workers through these browser-local URLs. They are website resources,
    // and must reach its local handler rather than the native-app notice.
    if(!url||['http:','https:','data:','blob:'].includes(url.protocol))return null;
    const headers={'Content-Type':document?'text/html; charset=utf-8':'text/plain; charset=utf-8','Cache-Control':'no-store',
      'Cross-Origin-Embedder-Policy':'require-corp','Cross-Origin-Opener-Policy':'same-origin','Cross-Origin-Resource-Policy':'same-origin',
      'Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff',
      'Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"};
    if(!document)return new Response('This protocol is not a website.',{status:400,headers});
    const roblox=url.protocol==='roblox-player:'||url.protocol==='roblox:'&&url.hostname==='experiences'&&url.pathname==='/start';
    const place=url.searchParams.get('placeId'),original=roblox&&/^\d{1,20}$/.test(place||'')?'https://www.roblox.com/games/'+place+'/':'https://www.roblox.com/';
    const title=roblox?'Roblox needs its app':'This link opens another app';
    const message=roblox?'This Roblox Play button starts the Roblox app, which cannot run inside Orbit. No browser streaming option has been verified to work in Orbit yet.':'This link uses an app protocol that Orbit cannot load as a website.';
    const actions=roblox?'<a href="/browse/'+escape(encodeURIComponent(original))+'">Return to Roblox in Orbit</a>':'';
    return new Response('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>html{color-scheme:dark}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#181b22;color:#e9edf2;font:16px/1.6 system-ui}main{max-width:540px;padding:32px}h1{font-size:26px;line-height:1.2}p{color:#b5becb}.brand{color:#c1df6b;letter-spacing:.12em;font-size:12px}nav{display:flex;flex-wrap:wrap;gap:12px;margin:24px 0}a{padding:10px 16px;border:1px solid #424953;border-radius:8px;color:#e9edf2;text-decoration:none}a:focus-visible{outline:3px solid #fff;outline-offset:3px}</style></head><body><main><p class="brand">ORBIT</p><h1>'+title+'</h1><p>'+message+'</p><nav>'+actions+'</nav></main></body></html>',{headers});
  }
  self.OrbitAppLinks={destination,response};
})();
