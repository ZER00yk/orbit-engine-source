/* Observe PokéRogue startup without changing or completing any loader work. */
(()=>{
  let report;
  try{report=window.parent.__orbitGameDiagnostics;}catch{}
  if(typeof report!=='function')return;
  const source=window,started=Date.now(),loaders=new Map();
  let lastError=null,lastSent='',lastChange=Date.now(),lastSnapshot='';
  const clean=value=>String(value||'').replace(/https?:\/\/\S+/gi,'[URL]').replace(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi,'[email]').replace(/(?:token|password|authorization|cookie)\s*[:=]\s*\S+/gi,'[private value]').replace(/[a-z0-9_=-]{28,}/gi,'[value]').slice(0,240);
  const errorDetails=(error,event)=>{
    let stack='';try{stack=String(error?.stack||'');}catch{}
    const frames=stack.split('\n').slice(1,7).map(line=>{
      const file=line.match(/[\w.-]+\.js:\d+(?::\d+)?/)?.[0];
      const method=line.match(/^\s*at\s+([\w.$<> ]+)\s*\(/)?.[1]?.trim();
      return file?(method?clean(method)+' @ ':'')+file:null;
    }).filter(Boolean).slice(0,4);
    if(!frames.length&&event?.filename){const file=event.filename.match(/[\w.-]+\.js/)?.[0];if(file)frames.push(file+':'+event.lineno+':'+event.colno);}
    return {name:clean(error?.name||'Error'),message:clean(error?.message||error),frames};
  };
  const send=payload=>{
    const encoded=JSON.stringify(payload);
    if(encoded===lastSent)return;
    lastSent=encoded;
    try{report(source,payload);}catch{}
  };
  const failure=(error,event)=>{lastError=errorDetails(error,event);send({stage:'error',error:lastError});};
  window.addEventListener('error',event=>{if(event.error||event.message)failure(event.error||event.message,event);});
  window.addEventListener('unhandledrejection',event=>failure(event.reason));
  function observe(phaser){
    const prototype=phaser?.Loader?.LoaderPlugin?.prototype;
    if(!prototype||typeof prototype.nextFile!=='function')return;
    const nextFile=prototype.nextFile;
    prototype.nextFile=function(...args){
      if(!loaders.has(this)){
        const scene=String(this.scene?.sys?.settings?.key||'loading').slice(0,40);
        loaders.set(this,{scene,complete:false});
        this.once('complete',()=>{loaders.get(this).complete=true;lastChange=Date.now();send({stage:'complete',scene});});
      }
      try{return nextFile.apply(this,args);}catch(error){failure(error);throw error;}
    };
  }
  const descriptor=Object.getOwnPropertyDescriptor(window,'Phaser');
  if(window.Phaser)observe(window.Phaser);
  else if(!descriptor||descriptor.configurable){
    Object.defineProperty(window,'Phaser',{configurable:true,enumerable:true,get:()=>undefined,set(value){Object.defineProperty(window,'Phaser',{value,writable:true,configurable:true,enumerable:true});observe(value);}});
  }
  const timer=setInterval(()=>{
    const active=Array.from(loaders).filter(([,info])=>!info.complete).at(-1);
    if(active){
      const [loader,info]=active;
      const pending=Array.from(loader.queue?.entries||[]).slice(0,12).map(file=>({type:String(file.type||'').slice(0,20),key:String(file.key||'').slice(0,100),state:Number(file.state)||0}));
      const snapshot={scene:info.scene,downloaded:Number(loader.totalComplete)||0,failed:Number(loader.totalFailed)||0,waiting:Number(loader.list?.size)||0,downloading:Number(loader.inflight?.size)||0,processing:Number(loader.queue?.size)||0,pending};
      const signature=JSON.stringify(snapshot);
      if(signature!==lastSnapshot){lastSnapshot=signature;lastChange=Date.now();}
      if(Date.now()-lastChange>12000)send({stage:'stalled',...snapshot,error:lastError});
    }else if(!loaders.size&&Date.now()-started>30000)send({stage:'starting',error:lastError});
    if(Date.now()-started>180000){clearInterval(timer);}
  },1000);
  window.addEventListener('pagehide',()=>clearInterval(timer),{once:true});
})();
